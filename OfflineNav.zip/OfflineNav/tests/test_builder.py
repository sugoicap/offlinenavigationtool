"""Round-trip test for tools/build_region.py (run: python3 tests/test_builder.py)."""
import gzip, heapq, os, struct, subprocess, sys, tempfile
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
from build_region import dist_m  # noqa


def make_osm(path):
    # 4x4 grid of junctions, spacing 0.01 deg; one-way row, one roundabout-flagged way,
    # a curved way with interior (non-junction) points, a footway that must be ignored.
    lines = ['<osm version="0.6">']
    nid = {}
    n = 1
    for r in range(4):
        for c in range(4):
            nid[(r, c)] = n
            lines.append('<node id="%d" lat="%.6f" lon="%.6f"/>' % (n, 47.50 + r * 0.01, 19.00 + c * 0.01))
            n += 1
    lines.append('<node id="900" lat="47.505" lon="19.005"><tag k="place" v="village"/><tag k="name" v="Tesztfalu"/></node>')
    wid = 1
    for r in range(4):
        refs = ''.join('<nd ref="%d"/>' % nid[(r, c)] for c in range(4))
        extra = '<tag k="oneway" v="yes"/>' if r == 2 else ''
        lines.append('<way id="%d">%s<tag k="highway" v="residential"/><tag k="name" v="Sor %d utca"/>%s</way>' % (wid, refs, r, extra))
        wid += 1
    for c in range(4):
        refs = ''.join('<nd ref="%d"/>' % nid[(r, c)] for r in range(4))
        lines.append('<way id="%d">%s<tag k="highway" v="secondary"/><tag k="name" v="Oszlop %d ut"/><tag k="maxspeed" v="70"/></way>' % (wid, refs, c))
        wid += 1
    lines.append('<way id="50"><nd ref="%d"/><nd ref="%d"/><tag k="highway" v="footway"/></way>' % (nid[(0, 0)], nid[(1, 1)]))
    lines.append('</osm>')
    open(path, 'w').write('\n'.join(lines))
    return nid


def read_region(path):
    raw = gzip.open(path, 'rb').read()
    p = 0
    assert raw[:4] == b'ONAV'; p = 4
    ver, N, E, S, G, P, Q, T = struct.unpack_from('<IIIIIIII', raw, p); p += 32
    assert ver == 1
    bbox = struct.unpack_from('<iiii', raw, p); p += 16
    offs = np.frombuffer(raw, '<u4', T + 1, p); p += 4 * (T + 1)
    blen, = struct.unpack_from('<I', raw, p); p += 4
    blob = raw[p:p + blen]; p += blen
    strings = [blob[offs[i]:offs[i + 1]].decode() for i in range(T)]

    def arr(dt, n):
        nonlocal p
        a = np.frombuffer(raw, dt, n, p); p += a.nbytes; return a
    d = {}
    d['nlat'] = arr('<i4', N); d['nlon'] = arr('<i4', N); d['first'] = arr('<u4', N + 1)
    d['eto'] = arr('<i4', E); d['eseg'] = arr('<i4', E)
    d['slen'] = arr('<f4', S); d['sspeed'] = arr('u1', S); d['scls'] = arr('u1', S); d['sflags'] = arr('u1', S)
    d['sname'] = arr('<i4', S); d['sstart'] = arr('<u4', S + 1)
    d['glat'] = np.cumsum(arr('<i4', G).astype(np.int64)); d['glon'] = np.cumsum(arr('<i4', G).astype(np.int64))
    d['plat'] = arr('<i4', P); d['plon'] = arr('<i4', P); d['pkind'] = arr('u1', P); d['pname'] = arr('<i4', P)
    d['qlat'] = arr('<i4', Q); d['qlon'] = arr('<i4', Q); d['qname'] = arr('<i4', Q)
    assert p == len(raw), (p, len(raw))
    d.update(strings=strings, bbox=bbox, N=N, E=E, S=S)
    return d


def dijkstra(d, src, dst):
    dist = {src: 0.0}; pq = [(0.0, src)]
    while pq:
        c, n = heapq.heappop(pq)
        if n == dst: return c
        if c > dist.get(n, 1e18): continue
        for e in range(d['first'][n], d['first'][n + 1]):
            nc = c + float(d['slen'][d['eseg'][e] >> 1]); t = int(d['eto'][e])
            if nc < dist.get(t, 1e18):
                dist[t] = nc; heapq.heappush(pq, (nc, t))
    return None


def main():
    tmp = tempfile.mkdtemp()
    osm = os.path.join(tmp, 't.osm'); make_osm(osm)
    out = os.path.join(tmp, 'out'); idx = os.path.join(tmp, 'index.json')
    subprocess.check_call([sys.executable, os.path.join(ROOT, 'tools', 'build_region.py'), osm, '--id', 'test',
                           '--name-hu', 'Teszt', '--out', out, '--index', idx])
    d = read_region(os.path.join(out, 'test.nav.gz'))
    print('nodes', d['N'], 'edges', d['E'], 'segments', d['S'], 'strings', d['strings'])
    assert d['N'] == 16, d['N']                    # 4x4 junctions, footway ignored
    assert d['S'] == 24, d['S']                    # 12 horizontal + 12 vertical pieces
    oneway = int((d['sflags'] & 1).sum()); assert oneway == 3, oneway
    assert d['E'] == 24 * 2 - 3, d['E']
    assert 'Tesztfalu' in d['strings'] and len(d['pname']) == 1
    assert d['bbox'][0] == 47500000 and d['bbox'][3] == 19030000
    # speed: secondary maxspeed 70 -> 0.85*70 = 60 (rounded), residential 30*0.85 = 26 (rounded)
    assert set(map(int, d['sspeed'])) == {60, 26}, set(d['sspeed'])
    # find node ids by coordinate and check routing both ways along an oneway row (row 2 goes west->east)
    def node(r, c):
        return int(np.where((d['nlat'] == 47500000 + r * 10000) & (d['nlon'] == 19000000 + c * 10000))[0][0])
    # shortest path (0,0)->(3,3) = 6 hops
    base = dijkstra(d, node(0, 0), node(3, 3))
    expect = 3 * dist_m(47500000, 19000000, 47510000, 19000000) + 3 * dist_m(47500000, 19000000, 47500000, 19010000)
    print('route', base, 'expected approx', expect)
    assert abs(base - expect) / expect < 0.02
    # row 2 is one-way W->E: (2,3)->(2,2) direct edge must not exist, but reachable around
    direct = dijkstra(d, node(2, 3), node(2, 2))
    straight = dist_m(47520000, 19030000, 47520000, 19020000)
    assert direct > straight * 1.5, (direct, straight)
    assert dijkstra(d, node(2, 0), node(2, 1)) < straight * 1.05
    print(open(idx).read())
    print('OK')


if __name__ == '__main__':
    main()
