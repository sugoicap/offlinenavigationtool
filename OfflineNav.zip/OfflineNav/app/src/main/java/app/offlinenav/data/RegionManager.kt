package app.offlinenav.data

import android.content.Context
import app.offlinenav.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

class RemoteRegion(
    val id: String,
    val nameHu: String,
    val nameEn: String,
    val file: String,
    val bytes: Long,
    val version: String,
    val bbox: IntArray
) {
    fun name(hu: Boolean) = if (hu) nameHu else nameEn
}

class InstalledRegion(
    val id: String,
    val nameHu: String,
    val nameEn: String,
    val version: String,
    val bytes: Long,
    val bbox: IntArray,
    val file: File
) {
    fun name(hu: Boolean) = if (hu) nameHu else nameEn
    fun contains(lat: Int, lon: Int) = lat in bbox[0]..bbox[2] && lon in bbox[1]..bbox[3]
    fun area(): Long = (bbox[2] - bbox[0]).toLong() * (bbox[3] - bbox[1]).toLong()
}

/** Downloads, lists and deletes region files in the app's private storage. */
class RegionManager(ctx: Context) {
    private val dir = File(ctx.filesDir, "regions").also { it.mkdirs() }

    fun installed(): List<InstalledRegion> {
        val out = ArrayList<InstalledRegion>()
        dir.listFiles { f -> f.name.endsWith(".meta.json") }?.forEach { m ->
            try {
                val j = JSONObject(m.readText())
                val id = j.getString("id")
                val f = File(dir, "$id.nav.gz")
                if (!f.exists()) return@forEach
                val b = j.getJSONArray("bbox")
                out.add(
                    InstalledRegion(
                        id, j.optString("name_hu", id), j.optString("name_en", id),
                        j.optString("version", ""), f.length(),
                        intArrayOf(b.getInt(0), b.getInt(1), b.getInt(2), b.getInt(3)), f
                    )
                )
            } catch (_: Exception) {
            }
        }
        return out.sortedBy { it.nameEn }
    }

    suspend fun fetchIndex(): List<RemoteRegion> = withContext(Dispatchers.IO) {
        val url = URL(BuildConfig.MAPS_BASE + "index.json")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr: JSONArray = JSONObject(text).getJSONArray("regions")
            val out = ArrayList<RemoteRegion>()
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val b = j.getJSONArray("bbox")
                out.add(
                    RemoteRegion(
                        j.getString("id"), j.optString("name_hu", j.getString("id")),
                        j.optString("name_en", j.getString("id")), j.getString("file"),
                        j.optLong("bytes", 0L), j.optString("version", ""),
                        intArrayOf(b.getInt(0), b.getInt(1), b.getInt(2), b.getInt(3))
                    )
                )
            }
            out
        } finally {
            conn.disconnect()
        }
    }

    suspend fun download(r: RemoteRegion, onProgress: (Long, Long) -> Unit) = withContext(Dispatchers.IO) {
        val part = File(dir, "${r.id}.nav.gz.part")
        val conn = URL(BuildConfig.MAPS_BASE + r.file).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else r.bytes
            var done = 0L
            conn.inputStream.use { input ->
                part.outputStream().buffered(1 shl 16).use { out ->
                    val buf = ByteArray(1 shl 16)
                    var lastReport = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done - lastReport > 200_000) {
                            lastReport = done
                            onProgress(done, total)
                        }
                    }
                }
            }
            onProgress(done, total)
            val target = File(dir, "${r.id}.nav.gz")
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) throw IllegalStateException("rename failed")
            val meta = JSONObject()
                .put("id", r.id).put("name_hu", r.nameHu).put("name_en", r.nameEn)
                .put("version", r.version)
                .put("bbox", JSONArray(r.bbox.toList()))
            File(dir, "${r.id}.meta.json").writeText(meta.toString())
        } catch (e: Exception) {
            part.delete()
            throw e
        } finally {
            conn.disconnect()
        }
    }

    fun delete(id: String) {
        File(dir, "$id.nav.gz").delete()
        File(dir, "$id.meta.json").delete()
        File(dir, "$id.nav.gz.part").delete()
    }
}
