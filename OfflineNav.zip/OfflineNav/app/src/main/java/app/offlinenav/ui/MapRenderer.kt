package app.offlinenav.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import app.offlinenav.Dest
import app.offlinenav.Fix
import app.offlinenav.data.RegionData
import app.offlinenav.routing.Route
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MapColors(
    val bg: Int, val casing: Int, val fills: IntArray, val lowFills: IntArray,
    val text: Int, val halo: Int, val route: Int, val routeCasing: Int, val me: Int
) {
    companion object {
        val light = MapColors(
            bg = 0xFFF3F3F1.toInt(), casing = 0xFFCFCFCA.toInt(),
            fills = intArrayOf(0xFFF6C453.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt()),
            lowFills = intArrayOf(0xFFE5B042.toInt(), 0xFFBDBDB8.toInt(), 0xFFCDCDC8.toInt(), 0xFFD8D8D3.toInt(), 0xFFE0E0DB.toInt()),
            text = 0xFF3C3C3A.toInt(), halo = 0xFFF3F3F1.toInt(),
            route = 0xFF1A73E8.toInt(), routeCasing = 0xFFFFFFFF.toInt(), me = 0xFF1A73E8.toInt()
        )
        val dark = MapColors(
            bg = 0xFF000000.toInt(), casing = 0xFF000000.toInt(),
            fills = intArrayOf(0xFFB8862B.toInt(), 0xFF67676E.toInt(), 0xFF54545A.toInt(), 0xFF45454A.toInt(), 0xFF38383D.toInt()),
            lowFills = intArrayOf(0xFF9A7226.toInt(), 0xFF55555B.toInt(), 0xFF46464B.toInt(), 0xFF3A3A3F.toInt(), 0xFF2E2E33.toInt()),
            text = 0xFFB5B5B8.toInt(), halo = 0xFF000000.toInt(),
            route = 0xFF4C9AFF.toInt(), routeCasing = 0xFF0B2A57.toInt(), me = 0xFF4C9AFF.toInt()
        )
    }
}

private class FloatBuf(cap: Int = 8192) {
    var a = FloatArray(cap)
    var n = 0
    fun clear() {
        n = 0
    }

    fun add4(x1: Float, y1: Float, x2: Float, y2: Float) {
        if (n + 4 > a.size) a = a.copyOf(a.size * 2)
        a[n] = x1; a[n + 1] = y1; a[n + 2] = x2; a[n + 3] = y2
        n += 4
    }
}

/** Draws roads, place names, the route, your position and the destination on a plain Android Canvas. */
class MapRenderer(private val density: Float) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
    }
    private val bufs = Array(5) { FloatBuf() }
    private val routeBuf = FloatBuf()
    private val path = Path()

    // meters of real road width per class bucket, plus min/max pixel width (in dp)
    private val widthM = floatArrayOf(22f, 15f, 11f, 8f, 6f)
    private val minDp = floatArrayOf(2.4f, 2.0f, 1.7f, 1.4f, 1.2f)
    private val maxDp = floatArrayOf(14f, 12f, 10f, 8f, 7f)

    private fun bucket(cls: Int): Int = when {
        cls <= 1 -> 0
        cls == 2 -> 1
        cls == 3 -> 2
        cls == 4 -> 3
        else -> 4
    }

    /** Smallest class bucket shown at this zoom (4 = everything). */
    private fun maxBucket(mpp: Float): Int = when {
        mpp > 900f -> 1
        mpp > 350f -> 2
        mpp > 130f -> 3
        else -> 4
    }

    fun draw(
        cv: Canvas, w: Float, h: Float,
        camLat: Double, camLon: Double, mpp: Float, bearing: Float, anchor: Float,
        region: RegionData?, cursor: RegionData.Cursor?,
        route: Route?, routeFrom: Int,
        fix: Fix?, dest: Dest?, navigating: Boolean, c: MapColors
    ) {
        cv.drawColor(c.bg)
        cv.save()
        cv.translate(w / 2f, h * anchor)
        cv.rotate(-bearing)

        val cLat = (camLat * 1e6).toInt()
        val cLon = (camLon * 1e6).toInt()
        val kx = (0.11132 * cos(Math.toRadians(camLat)) / mpp).toFloat()
        val ky = (0.110574 / mpp).toFloat()

        if (region != null && cursor != null) {
            val radiusM = hypot(w, h) * mpp * 0.75f
            val dLat = (radiusM / 0.110574).toInt()
            val dLon = (radiusM / (0.11132 * cos(Math.toRadians(camLat)))).toInt()
            val count = cursor.query(cLat - dLat, cLon - dLon, cLat + dLat, cLon + dLon)
            val mb = maxBucket(mpp)
            for (b in bufs) b.clear()
            val buf = cursor.buf
            for (k in 0 until count) {
                val s = buf[k]
                val bk = bucket(region.segClass[s].toInt() and 0xFF)
                if (bk > mb) continue
                val out = bufs[bk]
                val st = region.segStart[s]
                val en = region.segStart[s + 1]
                var px = (region.geoLon[st] - cLon) * kx
                var py = -(region.geoLat[st] - cLat) * ky
                for (i in st + 1 until en) {
                    val x = (region.geoLon[i] - cLon) * kx
                    val y = -(region.geoLat[i] - cLat) * ky
                    out.add4(px, py, x, y)
                    px = x; py = y
                }
            }
            val casing = mpp < 150f
            for (bk in 4 downTo 0) {
                val bf = bufs[bk]
                if (bf.n == 0) continue
                val wpx = (widthM[bk] / mpp).coerceIn(minDp[bk] * density, maxDp[bk] * density)
                if (casing) {
                    line.color = c.casing
                    line.strokeWidth = wpx + 1.6f * density
                    cv.drawLines(bf.a, 0, bf.n, line)
                }
                line.color = if (casing) c.fills[bk] else c.lowFills[bk]
                line.strokeWidth = wpx
                cv.drawLines(bf.a, 0, bf.n, line)
            }

            if (bearing == 0f) drawPlaces(cv, region, cLat, cLon, kx, ky, w, h, anchor, mpp, c)
        }

        // Route
        if (route != null) {
            routeBuf.clear()
            val from = max(routeFrom, 0)
            var px = (route.lon[from] - cLon) * kx
            var py = -(route.lat[from] - cLat) * ky
            for (i in from + 1 until route.lat.size) {
                val x = (route.lon[i] - cLon) * kx
                val y = -(route.lat[i] - cLat) * ky
                routeBuf.add4(px, py, x, y)
                px = x; py = y
            }
            line.color = c.routeCasing
            line.strokeWidth = 11f * density
            cv.drawLines(routeBuf.a, 0, routeBuf.n, line)
            line.color = c.route
            line.strokeWidth = 7f * density
            cv.drawLines(routeBuf.a, 0, routeBuf.n, line)
        }

        // Destination pin
        if (dest != null) {
            val x = (dest.lon - cLon) * kx
            val y = -(dest.lat - cLat) * ky
            fillP.color = 0xFFE53935.toInt()
            cv.drawCircle(x, y, 9f * density, fillP)
            fillP.color = 0xFFFFFFFF.toInt()
            cv.drawCircle(x, y, 3.5f * density, fillP)
        }

        // Me
        if (fix != null) {
            val x = ((fix.lon * 1e6).toInt() - cLon) * kx
            val y = -((fix.lat * 1e6).toInt() - cLat) * ky
            cv.save()
            cv.translate(x, y)
            if (fix.hasBearing || navigating) {
                cv.rotate(fix.bearing + 0f)
                // heading arrow (pointing up in its own frame)
                path.reset()
                path.moveTo(0f, -15f * density)
                path.lineTo(10f * density, 11f * density)
                path.lineTo(0f, 6f * density)
                path.lineTo(-10f * density, 11f * density)
                path.close()
                fillP.color = 0xFFFFFFFF.toInt()
                cv.save(); cv.scale(1.25f, 1.25f); cv.drawPath(path, fillP); cv.restore()
                fillP.color = c.me
                cv.drawPath(path, fillP)
            } else {
                fillP.color = 0xFFFFFFFF.toInt()
                cv.drawCircle(0f, 0f, 9f * density, fillP)
                fillP.color = c.me
                cv.drawCircle(0f, 0f, 6.5f * density, fillP)
            }
            cv.restore()
        }
        cv.restore()
    }

    private fun drawPlaces(
        cv: Canvas, r: RegionData, cLat: Int, cLon: Int, kx: Float, ky: Float,
        w: Float, h: Float, anchor: Float, mpp: Float, c: MapColors
    ) {
        val maxKind = when {
            mpp > 900f -> 0
            mpp > 300f -> 1
            mpp > 70f -> 2
            mpp > 30f -> 3
            else -> 4
        }
        val sizes = floatArrayOf(17f, 15f, 13f, 11.5f, 10.5f)
        val taken = HashSet<Long>()
        val left = -w / 2f - 80f
        val right = w / 2f + 80f
        val top = -h * anchor - 20f
        val bottom = h * (1f - anchor) + 20f
        var drawn = 0
        for (kind in 0..min(maxKind, 4)) {
            textP.textSize = sizes[kind] * density
            haloP.textSize = textP.textSize
            haloP.strokeWidth = 3f * density
            textP.color = c.text
            haloP.color = c.halo
            textP.isFakeBoldText = kind <= 1
            for (i in 0 until r.placeLat.size) {
                if ((r.placeKind[i].toInt() and 0xFF) != kind) continue
                val x = (r.placeLon[i] - cLon) * kx
                val y = -(r.placeLat[i] - cLat) * ky
                if (x < left || x > right || y < top || y > bottom) continue
                val key = ((x / (95f * density)).toInt().toLong() shl 32) xor (y / (22f * density)).toInt().toLong()
                if (!taken.add(key)) continue
                val name = r.strings[r.placeName[i]]
                cv.drawText(name, x, y, haloP)
                cv.drawText(name, x, y, textP)
                if (++drawn > 80) return
            }
        }
    }
}
