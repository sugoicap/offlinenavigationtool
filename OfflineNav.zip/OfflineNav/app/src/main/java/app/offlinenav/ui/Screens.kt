package app.offlinenav.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.offlinenav.BuildConfig
import app.offlinenav.NavViewModel
import app.offlinenav.Screen
import app.offlinenav.routing.MType
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private fun scheme(dark: Boolean): ColorScheme = if (dark) darkColorScheme(
    primary = Color(0xFF4C9AFF), onPrimary = Color.Black,
    background = Color.Black, onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF121214), onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF1F1F23), onSurfaceVariant = Color(0xFFB5B5B8),
    error = Color(0xFFFF6B6B)
) else lightColorScheme(
    primary = Color(0xFF1A73E8), onPrimary = Color.White,
    background = Color(0xFFF3F3F1), onBackground = Color(0xFF1B1B1D),
    surface = Color.White, onSurface = Color(0xFF1B1B1D),
    surfaceVariant = Color(0xFFE8E8E5), onSurfaceVariant = Color(0xFF5B5B5E),
    error = Color(0xFFD93025)
)

@Composable
fun NavApp(vm: NavViewModel, systemDark: Boolean) {
    val dark = when (vm.theme) {
        "dark" -> true
        "light" -> false
        else -> systemDark
    }
    MaterialTheme(colorScheme = scheme(dark)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (vm.screen) {
                Screen.MAP -> MapScreen(vm, dark)
                Screen.SEARCH -> SearchScreen(vm)
                Screen.REGIONS -> RegionsScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
    BackHandler(enabled = vm.screen != Screen.MAP) { vm.screen = Screen.MAP }
}

// ------------------------------------------------------------------------------------------
// Map screen
// ------------------------------------------------------------------------------------------

@Composable
private fun MapScreen(vm: NavViewModel, dark: Boolean) {
    Box(Modifier.fillMaxSize()) {
        MapView(vm, dark)
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (vm.navigating) NavOverlay(vm) else BrowseOverlay(vm)
        }
    }
}

@Composable
private fun MapView(vm: NavViewModel, dark: Boolean) {
    val density = LocalDensity.current.density
    val renderer = remember(density) { MapRenderer(density) }
    val region = vm.region
    val cursor = remember(region) { region?.Cursor() }
    val colors = if (dark) MapColors.dark else MapColors.light
    Canvas(
        Modifier
            .fillMaxSize()
            .onSizeChanged { vm.viewW = it.width.toFloat(); vm.viewH = it.height.toFloat() }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (zoom != 1f) vm.onZoom(zoom)
                    if (pan != Offset.Zero) vm.onPan(pan.x, pan.y)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { vm.onLongPress(it.x, it.y) })
            }
    ) {
        drawIntoCanvas { canvas ->
            renderer.draw(
                canvas.nativeCanvas, size.width, size.height,
                vm.camLat, vm.camLon, vm.mpp, vm.camBearing, vm.anchor(),
                region, cursor, vm.route, if (vm.navigating) vm.progressIndex else 0,
                vm.fix, vm.dest, vm.navigating, colors
            )
        }
    }
}

@Composable
private fun RoundButton(label: String, onClick: () -> Unit) {
    Surface(
        Modifier.size(48.dp).clickable(onClick = onClick),
        shape = CircleShape, color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp
    ) {
        Box(contentAlignment = Alignment.Center) { Text(label, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface) }
    }
}

@Composable
private fun BrowseOverlay(vm: NavViewModel) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                Modifier.weight(1f).height(52.dp).clickable { vm.screen = Screen.SEARCH },
                shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp
            ) {
                Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        L("Hová megyünk?", "Where to?"), fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            RoundButton("⬇") { vm.screen = Screen.REGIONS }
            Spacer(Modifier.width(10.dp))
            RoundButton("⚙") { vm.screen = Screen.SETTINGS }
        }
        if (vm.regionLoading) {
            Spacer(Modifier.height(10.dp))
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(L("Térkép betöltése…", "Loading map…"), fontSize = 14.sp)
                }
            }
        }
        if (vm.regionError != null) {
            Spacer(Modifier.height(10.dp))
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
                Text(
                    if (vm.regionError == "memory") L("Nincs elég memória ehhez a térképhez.", "Not enough memory for this map.")
                    else L("A térkép nem tölthető be. Töltsd le újra.", "Could not load the map. Try downloading it again."),
                    Modifier.padding(14.dp), color = MaterialTheme.colorScheme.error, fontSize = 14.sp
                )
            }
        }
        if (vm.region == null && !vm.regionLoading && vm.installed.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp) {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(L("Még nincs térkép", "No map yet"), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            L("Tölts le egy országot vagy régiót, és offline is működik a navigáció.",
                                "Download a country or region and navigation works offline."),
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { vm.screen = Screen.REGIONS }) { Text(L("Térképek letöltése", "Download maps")) }
                    }
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Column(horizontalAlignment = Alignment.End) {
                RoundButton("+") { vm.onZoom(1.6f) }
                Spacer(Modifier.height(8.dp))
                RoundButton("−") { vm.onZoom(1f / 1.6f) }
                if (!vm.follow && vm.fix != null) {
                    Spacer(Modifier.height(8.dp))
                    RoundButton("◎") { vm.recenter() }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (vm.dest != null) DestCard(vm)
    }
}

@Composable
private fun DestCard(vm: NavViewModel) {
    val dest = vm.dest ?: return
    Surface(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(dest.name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            val r = vm.route
            when {
                vm.routing -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(L("Útvonal keresése…", "Finding route…"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                vm.routeError != null -> Text(
                    when (vm.routeError) {
                        "noregion" -> L("Ehhez töltsd le a térképet.", "Download the map for this area first.")
                        "start" -> L("A kiindulási pont közelében nincs út a térképen.", "No road near your start point.")
                        "end" -> L("A célpont közelében nincs út a térképen.", "No road near the destination.")
                        else -> L("Nem találtam útvonalat (a cél másik térképen lehet).", "No route found (the destination may be in another map).")
                    },
                    color = MaterialTheme.colorScheme.error
                )
                r != null -> {
                    Text(
                        "${fmtDur(r.totalS)}  ·  ${fmtDist(r.totalM)}  ·  ${L("érkezés", "arrive")} ${fmtEta(r.totalS)}",
                        fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (vm.fix == null) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            L("Nincs GPS jel: az útvonal a térkép közepétől indul.", "No GPS fix: route starts from the map center."),
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { vm.cancelDestination() }, Modifier.weight(1f)) { Text(L("Mégse", "Cancel")) }
                Button(onClick = { vm.startNavigation() }, Modifier.weight(1f), enabled = vm.route != null) {
                    Text(L("Indítás", "Start"))
                }
            }
        }
    }
}

@Composable
private fun NavOverlay(vm: NavViewModel) {
    val n = vm.navUi
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        if (n != null) {
            Surface(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface, shadowElevation = 10.dp
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    ManeuverIcon(n.type, MaterialTheme.colorScheme.onSurface, Modifier.size(64.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(fmtDist(n.distToNext), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text(maneuverText(n.type, n.exit), fontSize = 17.sp)
                        if (!n.street.isNullOrBlank()) {
                            Text(
                                n.street, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            val f = vm.fix
            if (f != null) {
                Surface(
                    Modifier.size(64.dp), shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp
                ) {
                    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text((f.speed * 3.6f).roundToInt().toString(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("km/h", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                RoundButton(if (vm.muted) "🔇" else "🔊") { vm.changeMuted(!vm.muted) }
                if (!vm.follow) {
                    Spacer(Modifier.height(8.dp))
                    RoundButton("◎") { vm.recenter() }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Surface(
            Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface, shadowElevation = 10.dp
        ) {
            if (vm.arrived) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(L("Megérkeztél", "You have arrived"), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.stopNavigation() }) { Text(L("Kész", "Done")) }
                }
            } else {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        if (n != null) {
                            Text(fmtEta(n.remainingS), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${fmtDur(n.remainingS)}  ·  ${fmtDist(n.remainingM)}", fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    TextButton(onClick = { vm.stopNavigation() }) {
                        Text(L("Kilépés", "Exit"), color = MaterialTheme.colorScheme.error, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ManeuverIcon(type: MType, tint: Color, modifier: Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val sw = s * 0.10f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        fun head(tip: Offset, dirX: Float, dirY: Float) {
            // two short lines going back from the tip, +-150 degrees from the travel direction
            for (a in floatArrayOf(150f, -150f)) {
                val r = Math.toRadians(a.toDouble())
                val bx = (dirX * cos(r) - dirY * sin(r)).toFloat()
                val by = (dirX * sin(r) + dirY * cos(r)).toFloat()
                drawLine(tint, tip, Offset(tip.x + bx * s * 0.2f, tip.y + by * s * 0.2f), sw, StrokeCap.Round)
            }
        }
        when (type) {
            MType.ARRIVE -> {
                drawCircle(tint, radius = s * 0.30f, center = p(0.5f, 0.5f), style = st)
                drawCircle(tint, radius = s * 0.10f, center = p(0.5f, 0.5f))
            }
            MType.ROUNDABOUT -> {
                drawCircle(tint, radius = s * 0.20f, center = p(0.5f, 0.42f), style = st)
                drawLine(tint, p(0.5f, 0.95f), p(0.5f, 0.62f), sw, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.22f), p(0.5f, 0.04f), sw, StrokeCap.Round)
                head(p(0.5f, 0.04f), 0f, -1f)
            }
            MType.UTURN -> {
                val path = Path().apply {
                    moveTo(0.64f * s, 0.92f * s)
                    lineTo(0.64f * s, 0.38f * s)
                    arcTo(Rect(0.36f * s, 0.12f * s, 0.64f * s, 0.64f * s), 0f, -180f, false)
                    lineTo(0.36f * s, 0.62f * s)
                }
                drawPath(path, tint, style = st)
                head(p(0.36f, 0.62f), 0f, 1f)
            }
            else -> {
                val angle = when (type) {
                    MType.LEFT -> -90f
                    MType.SLIGHT_LEFT -> -45f
                    MType.SHARP_LEFT -> -135f
                    MType.RIGHT -> 90f
                    MType.SLIGHT_RIGHT -> 45f
                    MType.SHARP_RIGHT -> 135f
                    else -> 0f
                }
                val r = Math.toRadians(angle.toDouble())
                val dx = sin(r).toFloat()
                val dy = -cos(r).toFloat()
                if (angle == 0f) {
                    drawLine(tint, p(0.5f, 0.92f), p(0.5f, 0.12f), sw, StrokeCap.Round)
                    head(p(0.5f, 0.12f), 0f, -1f)
                } else {
                    drawLine(tint, p(0.5f, 0.92f), p(0.5f, 0.55f), sw, StrokeCap.Round)
                    val tip = Offset(0.5f * s + dx * s * 0.38f, 0.55f * s + dy * s * 0.38f)
                    drawLine(tint, p(0.5f, 0.55f), tip, sw, StrokeCap.Round)
                    head(tip, dx, dy)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Search
// ------------------------------------------------------------------------------------------

@Composable
private fun SearchScreen(vm: NavViewModel) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(vm.query, vm.region) { vm.runSearch(vm.query) }
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.screen = Screen.MAP }) { Text("←", fontSize = 22.sp) }
            TextField(
                value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
                placeholder = { Text(L("Utca vagy település", "Street or place")) },
                modifier = Modifier.weight(1f).focusRequester(focus),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                )
            )
        }
        HorizontalDivider()
        if (vm.region == null) {
            Text(
                L("Keresés előtt tölts le egy térképet.", "Download a map before searching."),
                Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.results) { h ->
                    Column(Modifier.fillMaxWidth().clickable { vm.pickResult(h) }.padding(horizontal = 20.dp, vertical = 12.dp)) {
                        Text(h.title, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val sub = if (h.isPlace) L("Település", "Place") else h.subtitle
                        if (sub.isNotEmpty()) Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Regions (offline map downloads)
// ------------------------------------------------------------------------------------------

private fun mb(bytes: Long): String = String.format(java.util.Locale.US, "%.0f MB", bytes / 1e6)

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RegionsScreen(vm: NavViewModel) {
    LaunchedEffect(Unit) {
        vm.refreshInstalled()
        vm.loadIndex()
    }
    val hu = Lang.hu
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        Header(L("Offline térképek", "Offline maps")) { vm.screen = Screen.MAP }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            item {
                Text(L("Letöltve", "Downloaded"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                if (vm.installed.isEmpty()) {
                    Text(L("Még nincs letöltött térkép.", "No maps downloaded yet."), fontSize = 15.sp)
                }
            }
            items(vm.installed) { r ->
                Surface(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp), shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name(hu), fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            Text("${mb(r.bytes)}  ·  ${r.version}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { vm.deleteRegion(r.id) }) {
                            Text(L("Törlés", "Delete"), color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Text(L("Elérhető", "Available"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                when (vm.remoteState) {
                    "loading" -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    "error" -> {
                        Text(
                            L("A lista nem érhető el (internet kell hozzá, és előbb publikálni kell a térképeket).",
                                "Could not load the list (needs internet, and maps must be published first)."),
                            color = MaterialTheme.colorScheme.error, fontSize = 14.sp
                        )
                        TextButton(onClick = { vm.loadIndex() }) { Text(L("Újra", "Retry")) }
                    }
                    "ok" -> if (vm.remote.isEmpty()) Text(L("Még nincs publikált térkép.", "No maps published yet."), fontSize = 15.sp)
                }
            }
            items(vm.remote) { r ->
                val inst = vm.installed.firstOrNull { it.id == r.id }
                val progress = vm.downloading[r.id]
                Surface(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp), shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name(hu), fontSize = 17.sp, fontWeight = FontWeight.Medium)
                                Text("${mb(r.bytes)}  ·  ${r.version}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (progress != null) {
                                TextButton(onClick = { vm.cancelDownload(r.id) }) { Text(L("Mégse", "Cancel")) }
                            } else if (inst == null) {
                                Button(onClick = { vm.download(r) }) { Text(L("Letöltés", "Download")) }
                            } else if (inst.version != r.version) {
                                Button(onClick = { vm.download(r) }) { Text(L("Frissítés", "Update")) }
                            } else {
                                Text("✓", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        if (progress != null) {
                            Spacer(Modifier.height(10.dp))
                            LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth())
                        }
                        if (vm.downloadError == r.id) {
                            Text(L("A letöltés nem sikerült.", "Download failed."), color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Settings
// ------------------------------------------------------------------------------------------

@Composable
private fun Seg(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp)
    ) {
        for ((key, label) in options) {
            val sel = key == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onSelect(key) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: NavViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        Header(L("Beállítások", "Settings")) { vm.screen = Screen.MAP }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            item {
                Text(L("Nyelv", "Language"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Seg(listOf("hu" to "Magyar", "en" to "English"), vm.lang) { vm.changeLang(it) }
                Spacer(Modifier.height(20.dp))
                Text(L("Téma", "Theme"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Seg(
                    listOf("auto" to L("Auto", "Auto"), "light" to L("Világos", "Light"), "dark" to L("Sötét", "Dark")),
                    vm.theme
                ) { vm.changeTheme(it) }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(L("Hangos navigáció", "Voice guidance"), Modifier.weight(1f), fontSize = 17.sp)
                    Switch(checked = !vm.muted, onCheckedChange = { vm.changeMuted(!it) })
                }
                Spacer(Modifier.height(16.dp))
                Text(L("Hang", "Voice"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(vm.voice.packs) { p ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.setVoice(p.id) }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = vm.voiceId == p.id, onClick = { vm.setVoice(p.id) })
                    Text(p.name, fontSize = 16.sp)
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.voice.test() }) { Text(L("Hang kipróbálása", "Test voice")) }
                if (vm.voice.status == "missing_data") {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        L("Ehhez a nyelvhez nincs hangadat a telefonon. Telepítsd a Szövegfelolvasó beállításokban (Google TTS).",
                            "This language has no voice data on the phone. Install it in the text-to-speech settings (Google TTS)."),
                        color = MaterialTheme.colorScheme.error, fontSize = 14.sp
                    )
                    TextButton(onClick = {
                        try {
                            ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {
                        }
                    }) { Text(L("Szövegfelolvasó beállítások", "Text-to-speech settings")) }
                }
                Spacer(Modifier.height(28.dp))
                HorizontalDivider()
                Spacer(Modifier.height(12.dp))
                Text("OfflineNav ${BuildConfig.VERSION_NAME}", fontSize = 14.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    L("Térképadatok: © OpenStreetMap közreműködők (ODbL)", "Map data: © OpenStreetMap contributors (ODbL)"),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
