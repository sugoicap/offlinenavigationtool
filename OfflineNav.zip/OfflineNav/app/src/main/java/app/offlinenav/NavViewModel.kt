package app.offlinenav

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.offlinenav.data.Geo
import app.offlinenav.data.InstalledRegion
import app.offlinenav.data.RegionData
import app.offlinenav.data.RegionManager
import app.offlinenav.data.RemoteRegion
import app.offlinenav.data.SearchHit
import app.offlinenav.nav.NavSession
import app.offlinenav.routing.MType
import app.offlinenav.routing.Route
import app.offlinenav.routing.Router
import app.offlinenav.ui.L
import app.offlinenav.ui.Lang
import app.offlinenav.voice.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max

enum class Screen { MAP, SEARCH, REGIONS, SETTINGS }

class Fix(
    val lat: Double, val lon: Double, val speed: Float, val bearing: Float,
    val accuracy: Float, val hasBearing: Boolean
)

class Dest(val name: String, val lat: Int, val lon: Int)

class NavUi(
    val type: MType, val exit: Int, val distToNext: Float, val street: String?,
    val remainingM: Float, val remainingS: Float
)

class NavViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val regions = RegionManager(app)
    val voice = VoiceManager(app)

    // ---- settings ---------------------------------------------------------------
    var lang by mutableStateOf("hu")
        private set
    var theme by mutableStateOf(prefs.getString("theme", "auto") ?: "auto")
        private set
    var voiceId by mutableStateOf("")
        private set
    var muted by mutableStateOf(prefs.getBoolean("muted", false))
        private set

    var screen by mutableStateOf(Screen.MAP)

    init {
        lang = prefs.getString("lang", null) ?: if (Locale.getDefault().language == "hu") "hu" else "en"
        Lang.code = lang
        voice.muted = muted
        voiceId = prefs.getString("voice", null) ?: defaultVoiceFor(lang)
        voice.select(voiceId)
    }

    private fun defaultVoiceFor(l: String) = if (l == "hu") "hu-default" else "en-default"

    fun setLang(l: String) {
        lang = l; Lang.code = l
        prefs.edit().putString("lang", l).apply()
        // Switch to the default voice of the new language unless the user picked a custom one.
        val cur = voice.packs.firstOrNull { it.id == voiceId }
        if (cur == null || cur.id.endsWith("-default")) setVoice(defaultVoiceFor(l))
    }

    fun setTheme(t: String) {
        theme = t; prefs.edit().putString("theme", t).apply()
    }

    fun setVoice(id: String) {
        voiceId = id; voice.select(id); prefs.edit().putString("voice", id).apply()
    }

    fun setMuted(m: Boolean) {
        muted = m; voice.muted = m
        if (m) voice.stop()
        prefs.edit().putBoolean("muted", m).apply()
    }

    // ---- camera -----------------------------------------------------------------
    var camLat by mutableStateOf(47.4979)
    var camLon by mutableStateOf(19.0402)
    var mpp by mutableStateOf(60f)          // meters per pixel
    var camBearing by mutableStateOf(0f)
    var follow by mutableStateOf(true)
    var viewW = 0f
    var viewH = 0f

    fun onPan(dx: Float, dy: Float) {
        if (follow || camBearing != 0f) {
            follow = false; camBearing = 0f
        }
        camLat += dy * mpp / 110574.0
        camLon -= dx * mpp / (111320.0 * cos(Math.toRadians(camLat)))
        ensureRegion()
    }

    fun onZoom(factor: Float) {
        mpp = (mpp / factor).coerceIn(1.2f, 2500f)
    }

    fun recenter() {
        val f = fix ?: return
        follow = true
        camLat = f.lat; camLon = f.lon
        if (!navigating && mpp > 200f) mpp = 40f
        if (navigating) mpp = 12f
    }

    // ---- regions ----------------------------------------------------------------
    var region by mutableStateOf<RegionData?>(null)
        private set
    var regionLoading by mutableStateOf(false)
        private set
    var regionError by mutableStateOf<String?>(null)
        private set
    var installed by mutableStateOf<List<InstalledRegion>>(regions.installed())
        private set
    private var router: Router? = null
    private var loadingId: String? = null

    fun refreshInstalled() {
        installed = regions.installed()
        ensureRegion()
    }

    fun ensureRegion() {
        if (navigating) return
        val lat = (camLat * 1e6).toInt()
        val lon = (camLon * 1e6).toInt()
        val cand = installed.filter { it.contains(lat, lon) }.minByOrNull { it.area() }
            ?: installed.firstOrNull { it.id == region?.id }
            ?: installed.firstOrNull()
        if (cand == null) {
            region = null; router = null; return
        }
        if (region?.id == cand.id || loadingId == cand.id) return
        loadingId = cand.id
        regionLoading = true
        regionError = null
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val r = RegionData.load(cand.file, cand.id)
                val rt = Router(r)
                withContext(Dispatchers.Main) {
                    region = r; router = rt
                    regionLoading = false; loadingId = null
                    if (!r.contains((camLat * 1e6).toInt(), (camLon * 1e6).toInt()) && fix == null) {
                        camLat = (r.minLat + r.maxLat) / 2e6
                        camLon = (r.minLon + r.maxLon) / 2e6
                        mpp = 150f
                    }
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    regionLoading = false; loadingId = null
                    regionError = if (t is OutOfMemoryError) "memory" else "load"
                }
            }
        }
    }

    // ---- remote index & downloads -----------------------------------------------
    var remote by mutableStateOf<List<RemoteRegion>>(emptyList())
        private set
    var remoteState by mutableStateOf("idle")   // idle | loading | ok | error
        private set
    var downloading by mutableStateOf<Map<String, Float>>(emptyMap())
        private set
    var downloadError by mutableStateOf<String?>(null)
        private set
    private val dlJobs = HashMap<String, Job>()

    fun loadIndex() {
        remoteState = "loading"
        viewModelScope.launch {
            try {
                remote = regions.fetchIndex()
                remoteState = "ok"
            } catch (e: Exception) {
                remoteState = "error"
            }
        }
    }

    fun download(r: RemoteRegion) {
        if (dlJobs.containsKey(r.id)) return
        downloadError = null
        downloading = downloading + (r.id to 0f)
        dlJobs[r.id] = viewModelScope.launch {
            try {
                regions.download(r) { done, total ->
                    val frac = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
                    viewModelScope.launch(Dispatchers.Main) { downloading = downloading + (r.id to frac) }
                }
                refreshInstalled()
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) downloadError = r.id
            } finally {
                dlJobs.remove(r.id)
                downloading = downloading - r.id
            }
        }
    }

    fun cancelDownload(id: String) {
        dlJobs[id]?.cancel()
    }

    fun deleteRegion(id: String) {
        if (region?.id == id) {
            region = null; router = null
        }
        regions.delete(id)
        refreshInstalled()
    }

    // ---- location ---------------------------------------------------------------
    var fix by mutableStateOf<Fix?>(null)
        private set
    var hasLocationPermission by mutableStateOf(false)
    private var locStarted = false
    private var gotFirstFix = false
    private val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onLocation(location)
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocation() {
        hasLocationPermission = true
        if (locStarted) return
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
            locStarted = true
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocation(it) }
        } catch (_: Exception) {
        }
    }

    private fun onLocation(l: Location) {
        val hb = l.hasBearing() && l.speed > 1.5f
        val f = Fix(l.latitude, l.longitude, if (l.hasSpeed()) l.speed else 0f, l.bearing, if (l.hasAccuracy()) l.accuracy else 20f, hb)
        fix = f
        if (!gotFirstFix) {
            gotFirstFix = true
            if (!navigating) {
                camLat = f.lat; camLon = f.lon; mpp = 30f; follow = true
                ensureRegion()
            }
        }
        if (navigating) navUpdate(f)
        else if (follow) {
            camLat = f.lat; camLon = f.lon
        }
    }

    // ---- destination, route, navigation -----------------------------------------
    var dest by mutableStateOf<Dest?>(null)
        private set
    var route by mutableStateOf<Route?>(null)
        private set
    var routing by mutableStateOf(false)
        private set
    var routeError by mutableStateOf<String?>(null)
        private set
    var navigating by mutableStateOf(false)
        private set
    var arrived by mutableStateOf(false)
        private set
    var navUi by mutableStateOf<NavUi?>(null)
        private set
    var progressIndex by mutableStateOf(0)
        private set
    private var session: NavSession? = null
    private var routeJob: Job? = null
    private var rerouting = false
    private var lastReroute = 0L

    fun setDestination(name: String, lat: Int, lon: Int) {
        if (navigating) stopNavigation()
        dest = Dest(name, lat, lon)
        route = null
        routeError = null
        computeRoute(false)
    }

    fun onLongPress(px: Float, py: Float) {
        val r = region
        val lat = ((camLat - (py - viewH * anchor()) * mpp / 110574.0) * 1e6).toInt()
        val lon = ((camLon + (px - viewW / 2f) * mpp / (111320.0 * cos(Math.toRadians(camLat)))) * 1e6).toInt()
        viewModelScope.launch(Dispatchers.Default) {
            var name: String? = null
            if (r != null) {
                val snap = r.nearest(r.Cursor(), lat, lon, 80f)
                if (snap != null) name = r.nameOf(snap.seg)
            }
            withContext(Dispatchers.Main) {
                setDestination(name ?: L("Kiválasztott pont", "Dropped pin"), lat, lon)
            }
        }
    }

    fun anchor(): Float = if (navigating && follow) 0.7f else 0.5f

    private fun computeRoute(reroute: Boolean) {
        val rt = router
        val d = dest ?: return
        if (rt == null) {
            routeError = "noregion"; return
        }
        val f = fix
        val sLat = ((f?.lat ?: camLat) * 1e6).toInt()
        val sLon = ((f?.lon ?: camLon) * 1e6).toInt()
        routing = true
        routeJob?.cancel()
        routeJob = viewModelScope.launch(Dispatchers.Default) {
            val res = rt.route(sLat, sLon, d.lat, d.lon) { isActive }
            withContext(Dispatchers.Main) {
                routing = false
                rerouting = false
                val nr = res.route
                if (nr != null) {
                    route = nr
                    routeError = null
                    if (reroute && navigating) {
                        session = makeSession(nr); progressIndex = 0
                    } else {
                        fitRoute(nr)
                    }
                } else if (res.error != "cancelled" && !reroute) {
                    routeError = res.error
                }
            }
        }
    }

    private fun makeSession(r: Route) = NavSession(r) { kind, m, dist -> voice.announce(kind, m, dist) }

    private fun fitRoute(r: Route) {
        var minLa = Int.MAX_VALUE; var maxLa = Int.MIN_VALUE; var minLo = Int.MAX_VALUE; var maxLo = Int.MIN_VALUE
        for (i in r.lat.indices) {
            minLa = minOf(minLa, r.lat[i]); maxLa = maxOf(maxLa, r.lat[i])
            minLo = minOf(minLo, r.lon[i]); maxLo = maxOf(maxLo, r.lon[i])
        }
        val midLat = (minLa + maxLa) / 2e6
        val spanX = (maxLo - minLo) * 0.11132 * cos(Math.toRadians(midLat))
        val spanY = (maxLa - minLa) * 0.110574
        val w = max(viewW, 400f)
        val h = max(viewH, 600f)
        mpp = max(spanX / (w * 0.8), spanY / (h * 0.42)).toFloat().coerceIn(1.5f, 2500f)
        camLon = (minLo + maxLo) / 2e6
        camLat = midLat - (h * 0.12f * mpp) / 110574.0
        camBearing = 0f
        follow = false
    }

    fun startNavigation() {
        val r = route ?: return
        navigating = true
        arrived = false
        session = makeSession(r)
        progressIndex = 0
        follow = true
        camBearing = 0f
        mpp = 12f
        fix?.let { camLat = it.lat; camLon = it.lon }
        val first = r.maneuvers.getOrNull(1)
        navUi = NavUi(first?.type ?: MType.ARRIVE, first?.exit ?: 0, first?.atM ?: 0f, first?.street, r.totalM, r.totalS)
        voice.say("start")
    }

    private fun navUpdate(f: Fix) {
        val s = session ?: return
        val u = s.update((f.lat * 1e6).toInt(), (f.lon * 1e6).toInt(), f.speed, f.accuracy)
        navUi = NavUi(u.next.type, u.next.exit, u.distToNextM, u.next.street, u.remainingM, u.remainingS)
        progressIndex = s.progressIndex
        if (follow) {
            camLat = f.lat; camLon = f.lon
            if (f.hasBearing) {
                val diff = Geo.angleDiff(camBearing.toDouble(), f.bearing.toDouble())
                var nb = camBearing + diff * 0.5
                if (nb < 0) nb += 360.0
                if (nb >= 360.0) nb -= 360.0
                camBearing = nb.toFloat()
            }
        }
        if (u.arrived) {
            arrived = true
        } else if (u.offRoute && !rerouting && System.currentTimeMillis() - lastReroute > 10_000L) {
            rerouting = true
            lastReroute = System.currentTimeMillis()
            voice.say("reroute")
            computeRoute(true)
        }
    }

    fun stopNavigation() {
        navigating = false
        arrived = false
        session = null
        navUi = null
        route = null
        dest = null
        routeError = null
        camBearing = 0f
        follow = true
        voice.stop()
        mpp = 30f
        fix?.let { camLat = it.lat; camLon = it.lon }
        ensureRegion()
    }

    fun cancelDestination() {
        routeJob?.cancel()
        routing = false
        dest = null
        route = null
        routeError = null
    }

    // ---- search -----------------------------------------------------------------
    var query by mutableStateOf("")
    var results by mutableStateOf<List<SearchHit>>(emptyList())
        private set
    private var searchJob: Job? = null

    fun runSearch(q: String) {
        searchJob?.cancel()
        val r = region
        if (r == null || q.trim().length < 2) {
            results = emptyList(); return
        }
        val cLat = ((fix?.lat ?: camLat) * 1e6).toInt()
        val cLon = ((fix?.lon ?: camLon) * 1e6).toInt()
        searchJob = viewModelScope.launch(Dispatchers.Default) {
            delay(150)
            val hits = r.search(q, cLat, cLon)
            withContext(Dispatchers.Main) { if (q == query) results = hits }
        }
    }

    fun pickResult(h: SearchHit) {
        screen = Screen.MAP
        query = ""
        results = emptyList()
        setDestination(h.title + if (h.subtitle.isNotEmpty()) ", " + h.subtitle else "", h.lat, h.lon)
    }

    override fun onCleared() {
        try {
            lm.removeUpdates(listener)
        } catch (_: Exception) {
        }
        voice.shutdown()
    }
}
