package app.offlinenav.routing

import app.offlinenav.data.Geo
import app.offlinenav.data.RegionData
import app.offlinenav.data.Snap
import java.util.PriorityQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class MType { DEPART, SLIGHT_LEFT, LEFT, SHARP_LEFT, SLIGHT_RIGHT, RIGHT, SHARP_RIGHT, UTURN, ROUNDABOUT, ARRIVE }

class Maneuver(
    val type: MType,
    val atM: Float,
    val street: String?,
    val exit: Int,
    val lat: Int,
    val lon: Int
)

class Route(
    val lat: IntArray,
    val lon: IntArray,
    val cum: FloatArray,
    val totalM: Float,
    val totalS: Float,
    val maneuvers: List<Maneuver>
)

/** [error] is "start" (no road near you), "end" (no road near destination), "none" (no connection) or "cancelled". */
class RouteResult(val route: Route?, val error: String?)

internal class IntList(cap: Int = 1024) {
    var a = IntArray(cap)
    var size = 0
    fun add(v: Int) {
        if (size == a.size) a = a.copyOf(size * 2)
        a[size++] = v
    }
}

internal class Leg(val seg: Int, val startIdx: Int, val endIdx: Int, val endNode: Int)

class Router(private val d: RegionData) {

    private fun mps(seg: Int): Float = max(d.segSpeed[seg].toInt() and 0xFF, 5) / 3.6f

    private fun cumOf(seg: Int): FloatArray {
        val st = d.segStart[seg]
        val n = d.segStart[seg + 1] - st
        val cum = FloatArray(n)
        for (i in 1 until n) {
            cum[i] = cum[i - 1] + Geo.distM(d.geoLat[st + i - 1], d.geoLon[st + i - 1], d.geoLat[st + i], d.geoLon[st + i])
        }
        return cum
    }

    private fun key(f: Float, node: Int): Long =
        (java.lang.Float.floatToRawIntBits(f).toLong() shl 32) or node.toLong()

    fun route(
        fromLat: Int, fromLon: Int, toLat: Int, toLon: Int,
        isActive: () -> Boolean = { true }
    ): RouteResult {
        val cur = d.Cursor()
        val s = d.nearest(cur, fromLat, fromLon, 500f) ?: return RouteResult(null, "start")
        val t = d.nearest(cur, toLat, toLon, 1500f) ?: return RouteResult(null, "end")

        val lat = IntList()
        val lon = IntList()
        val legs = ArrayList<Leg>()
        var totalS: Float

        // Start and destination on the same road piece.
        if (s.seg == t.seg) {
            val oneway = d.isOneway(s.seg)
            if (t.along >= s.along || !oneway) {
                appendSlice(s.seg, s.along, t.along, lat, lon, legs, -1)
                totalS = abs(t.along - s.along) / mps(s.seg)
                return finish(lat, lon, legs, totalS, s, t)
            }
        }

        val n = d.nodeLat.size
        val g = FloatArray(n) { Float.MAX_VALUE }
        val prevNode = IntArray(n) { -1 }
        val prevEdge = IntArray(n) { -1 }
        val closed = BooleanArray(n)
        val pq = PriorityQueue<Long>()
        val maxMps = d.maxSpeedKph / 3.6f
        val destLat = t.lat
        val destLon = t.lon

        fun h(node: Int): Float = Geo.distM(d.nodeLat[node], d.nodeLon[node], destLat, destLon) / maxMps

        val sLen = cumOf(s.seg).last()
        val sa = d.segFrom[s.seg]
        val sb = d.segTo[s.seg]
        val costB = max(sLen - s.along, 0f) / mps(s.seg)
        g[sb] = costB
        pq.add(key(costB + h(sb), sb))
        if (!d.isOneway(s.seg)) {
            val costA = s.along / mps(s.seg)
            if (costA < g[sa]) {
                g[sa] = costA
                pq.add(key(costA + h(sa), sa))
            }
        }

        val tLen = cumOf(t.seg).last()
        val ea = d.segFrom[t.seg]
        val eb = d.segTo[t.seg]
        val endA = t.along / mps(t.seg)
        val endBAllowed = !d.isOneway(t.seg)
        val endB = max(tLen - t.along, 0f) / mps(t.seg)

        var best = Float.MAX_VALUE
        var bestNode = -1
        var bestSide = 0
        var pops = 0
        while (pq.isNotEmpty()) {
            val k = pq.poll()!!
            val node = (k and 0xFFFFFFFFL).toInt()
            val f = java.lang.Float.intBitsToFloat((k ushr 32).toInt())
            if (f >= best) break
            if (closed[node]) continue
            closed[node] = true
            if ((++pops and 0xFFF) == 0 && !isActive()) return RouteResult(null, "cancelled")
            if (node == ea) {
                val c = g[node] + endA
                if (c < best) {
                    best = c; bestNode = node; bestSide = 0
                }
            }
            if (node == eb && endBAllowed) {
                val c = g[node] + endB
                if (c < best) {
                    best = c; bestNode = node; bestSide = 1
                }
            }
            for (e in d.firstEdge[node] until d.firstEdge[node + 1]) {
                val to = d.edgeTo[e]
                if (closed[to]) continue
                val seg = d.edgeSeg[e] shr 1
                val ng = g[node] + d.segLen[seg] / mps(seg) + 1.5f
                if (ng < g[to]) {
                    g[to] = ng
                    prevNode[to] = node
                    prevEdge[to] = e
                    pq.add(key(ng + h(to), to))
                }
            }
        }
        if (bestNode < 0) return RouteResult(null, "none")

        // Reconstruct.
        val edges = ArrayList<Int>()
        var node = bestNode
        while (prevEdge[node] != -1) {
            edges.add(prevEdge[node])
            node = prevNode[node]
        }
        edges.reverse()
        val firstNode = node

        // Start partial piece.
        if (firstNode == sb) {
            appendSlice(s.seg, s.along, sLen, lat, lon, legs, firstNode)
        } else {
            appendSlice(s.seg, s.along, 0f, lat, lon, legs, firstNode)
        }
        for (e in edges) {
            val seg = d.edgeSeg[e] shr 1
            val rev = (d.edgeSeg[e] and 1) == 1
            val len = cumOf(seg).last()
            if (!rev) appendSlice(seg, 0f, len, lat, lon, legs, d.edgeTo[e])
            else appendSlice(seg, len, 0f, lat, lon, legs, d.edgeTo[e])
        }
        // End partial piece.
        if (bestSide == 0) appendSlice(t.seg, 0f, t.along, lat, lon, legs, -1)
        else appendSlice(t.seg, tLen, t.along, lat, lon, legs, -1)

        totalS = best
        return finish(lat, lon, legs, totalS, s, t)
    }

    /** Appends the part of [seg] between the two "along" positions, in travel order. */
    private fun appendSlice(
        seg: Int, from: Float, to: Float,
        lat: IntList, lon: IntList, legs: ArrayList<Leg>, endNode: Int
    ) {
        val st = d.segStart[seg]
        val cum = cumOf(seg)
        val n = cum.size
        val before = lat.size
        val startIdx = max(before - 1, 0)

        fun addPt(la: Int, lo: Int) {
            if (lat.size > 0 && lat.a[lat.size - 1] == la && lon.a[lon.size - 1] == lo) return
            lat.add(la); lon.add(lo)
        }

        fun interp(along: Float) {
            if (along <= 0f) {
                addPt(d.geoLat[st], d.geoLon[st]); return
            }
            if (along >= cum[n - 1]) {
                addPt(d.geoLat[st + n - 1], d.geoLon[st + n - 1]); return
            }
            var i = 1
            while (i < n - 1 && cum[i] < along) i++
            val span = max(cum[i] - cum[i - 1], 1e-6f)
            val tt = (along - cum[i - 1]) / span
            val la = (d.geoLat[st + i - 1] + tt * (d.geoLat[st + i] - d.geoLat[st + i - 1])).roundToInt()
            val lo = (d.geoLon[st + i - 1] + tt * (d.geoLon[st + i] - d.geoLon[st + i - 1])).roundToInt()
            addPt(la, lo)
        }

        interp(from)
        if (from <= to) {
            for (i in 0 until n) if (cum[i] > from + 0.01f && cum[i] < to - 0.01f) addPt(d.geoLat[st + i], d.geoLon[st + i])
        } else {
            for (i in n - 1 downTo 0) if (cum[i] < from - 0.01f && cum[i] > to + 0.01f) addPt(d.geoLat[st + i], d.geoLon[st + i])
        }
        interp(to)
        if (lat.size - 1 > startIdx || (before == 0 && lat.size > 1)) {
            legs.add(Leg(seg, startIdx, lat.size - 1, endNode))
        }
    }

    private fun finish(lat: IntList, lon: IntList, legs: ArrayList<Leg>, totalS: Float, s: Snap, t: Snap): RouteResult {
        val n = lat.size
        if (n < 2 || legs.isEmpty()) return RouteResult(null, "none")
        val la = lat.a.copyOf(n)
        val lo = lon.a.copyOf(n)
        val cum = FloatArray(n)
        for (i in 1 until n) cum[i] = cum[i - 1] + Geo.distM(la[i - 1], lo[i - 1], la[i], lo[i])
        val maneuvers = buildManeuvers(la, lo, cum, legs)
        return RouteResult(Route(la, lo, cum, cum[n - 1], max(totalS, 1f), maneuvers), null)
    }

    private fun hasNonRoundaboutExit(node: Int): Boolean {
        if (node < 0) return false
        for (e in d.firstEdge[node] until d.firstEdge[node + 1]) {
            if (!d.isRoundabout(d.edgeSeg[e] shr 1)) return true
        }
        return false
    }

    private fun bearingAt(la: IntArray, lo: IntArray, cum: FloatArray, j: Int, minIdx: Int, maxIdx: Int, forward: Boolean): Double {
        var p = j
        if (forward) {
            while (p < maxIdx && cum[p] - cum[j] < 20f) p++
            if (p == j) return 0.0
            return Geo.bearing(la[j], lo[j], la[p], lo[p])
        } else {
            while (p > minIdx && cum[j] - cum[p] < 20f) p--
            if (p == j) return 0.0
            return Geo.bearing(la[p], lo[p], la[j], lo[j])
        }
    }

    private fun buildManeuvers(la: IntArray, lo: IntArray, cum: FloatArray, legs: List<Leg>): List<Maneuver> {
        val out = ArrayList<Maneuver>()
        out.add(Maneuver(MType.DEPART, 0f, d.nameOf(legs[0].seg), 0, la[0], lo[0]))
        var i = 1
        while (i < legs.size) {
            val prev = legs[i - 1]
            val cur = legs[i]
            val node = prev.endNode
            val j = prev.endIdx
            val curRound = d.isRoundabout(cur.seg)
            val prevRound = d.isRoundabout(prev.seg)
            if (curRound && !prevRound) {
                var k = i
                var exits = 0
                while (k + 1 < legs.size && d.isRoundabout(legs[k + 1].seg)) {
                    if (hasNonRoundaboutExit(legs[k].endNode)) exits++
                    k++
                }
                if (k + 1 < legs.size) {
                    exits++
                    out.add(Maneuver(MType.ROUNDABOUT, cum[j], d.nameOf(legs[k + 1].seg), exits, la[j], lo[j]))
                    i = k + 2
                    continue
                } else {
                    break
                }
            }
            if (!curRound) {
                val inB = bearingAt(la, lo, cum, j, prev.startIdx, prev.endIdx, false)
                val outB = bearingAt(la, lo, cum, j, cur.startIdx, cur.endIdx, true)
                val a = Geo.angleDiff(inB, outB)
                var alts = 0
                if (node >= 0) {
                    for (e in d.firstEdge[node] until d.firstEdge[node + 1]) {
                        val sg = d.edgeSeg[e] shr 1
                        if (sg != cur.seg && sg != prev.seg) alts++
                    }
                }
                val aa = abs(a)
                if (alts >= 1 && aa > 22.0) {
                    val left = a < 0
                    val type = when {
                        aa <= 55.0 -> if (left) MType.SLIGHT_LEFT else MType.SLIGHT_RIGHT
                        aa <= 130.0 -> if (left) MType.LEFT else MType.RIGHT
                        aa <= 170.0 -> if (left) MType.SHARP_LEFT else MType.SHARP_RIGHT
                        else -> MType.UTURN
                    }
                    out.add(Maneuver(type, cum[j], d.nameOf(cur.seg), 0, la[j], lo[j]))
                }
            }
            i++
        }
        val end = cum.size - 1
        out.add(Maneuver(MType.ARRIVE, cum[end], null, 0, la[end], lo[end]))
        return out
    }
}
