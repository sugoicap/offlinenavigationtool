package app.offlinenav.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.offlinenav.nav.AnnounceKind
import app.offlinenav.routing.MType
import app.offlinenav.routing.Maneuver
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * A voice pack is just a JSON file: language, TTS locale and the phrases to say.
 * To add a voice: drop a new JSON next to hu-default.json in app/src/main/assets/voices/
 * (same keys), or put one in the app's files/voices/ folder. It shows up in Settings automatically.
 */
class VoicePack(
    val id: String,
    val name: String,
    val locale: String,
    val engine: String,
    val decimal: String,
    private val json: JSONObject
) {
    private fun str(group: String, key: String): String = json.optJSONObject(group)?.optString(key, "") ?: ""

    fun phrase(key: String) = str("phrases", key)
    fun action(key: String) = str("actions", key)
    fun unit(key: String) = str("units", key)
}

class VoiceManager(private val ctx: Context) {
    var packs: List<VoicePack> = emptyList()
        private set
    var current: VoicePack? = null
        private set

    /** Empty when fine, otherwise a short code: "missing_data" or "init_failed". */
    var status by mutableStateOf("")
        private set
    var muted: Boolean = false

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focus: AudioFocusRequest? = null

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    init {
        reloadPacks()
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ready = true
                tts?.setAudioAttributes(attrs)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = releaseFocus()
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = releaseFocus()
                })
                applyLanguage()
                pending?.let { speak(it); pending = null }
            } else {
                status = "init_failed"
            }
        }
    }

    fun reloadPacks() {
        val found = ArrayList<VoicePack>()
        fun parse(text: String) {
            try {
                val j = JSONObject(text)
                found.add(
                    VoicePack(
                        j.getString("id"), j.getString("name"), j.getString("locale"),
                        j.optString("engine", "tts"), j.optString("decimal", "."), j
                    )
                )
            } catch (_: Exception) {
            }
        }
        try {
            ctx.assets.list("voices")?.filter { it.endsWith(".json") }?.sorted()?.forEach { f ->
                parse(ctx.assets.open("voices/$f").bufferedReader().use { it.readText() })
            }
        } catch (_: Exception) {
        }
        File(ctx.filesDir, "voices").listFiles { f -> f.name.endsWith(".json") }?.sortedBy { it.name }?.forEach {
            parse(it.readText())
        }
        packs = found.distinctBy { it.id }
        if (current == null || packs.none { it.id == current?.id }) current = packs.firstOrNull()
    }

    fun select(id: String) {
        val p = packs.firstOrNull { it.id == id } ?: return
        current = p
        applyLanguage()
    }

    private fun applyLanguage() {
        val p = current ?: return
        if (!ready) return
        val r = tts?.setLanguage(Locale.forLanguageTag(p.locale))
        status = if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) "missing_data" else ""
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pending = text; return
        }
        requestFocus()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs).build()
        focus = req
        audio.requestAudioFocus(req)
    }

    private fun releaseFocus() {
        focus?.let { audio.abandonAudioFocusRequest(it) }
        focus = null
    }

    fun stop() {
        tts?.stop()
        releaseFocus()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    // ---- phrases ----------------------------------------------------------------

    fun say(key: String) {
        if (muted) return
        val p = current ?: return
        speak(p.phrase(key))
    }

    fun test() {
        val p = current ?: return
        speak(p.phrase("test"))
    }

    private fun distText(p: VoicePack, m: Float): String {
        if (m < 1000f) {
            val step = if (m < 150f) 10 else 50
            val v = (Math.round(m / step) * step).coerceAtLeast(10)
            return p.unit("m").replace("{n}", v.toString())
        }
        val km = Math.round(m / 100f) / 10.0
        val s = if (km == Math.floor(km)) km.toInt().toString() else km.toString().replace(".", p.decimal)
        return p.unit("km").replace("{n}", s)
    }

    private fun actionKey(t: MType): String = when (t) {
        MType.LEFT -> "left"
        MType.RIGHT -> "right"
        MType.SLIGHT_LEFT -> "slight_left"
        MType.SLIGHT_RIGHT -> "slight_right"
        MType.SHARP_LEFT -> "sharp_left"
        MType.SHARP_RIGHT -> "sharp_right"
        MType.UTURN -> "uturn"
        MType.ROUNDABOUT -> "roundabout"
        MType.ARRIVE, MType.DEPART -> "arrive"
    }

    fun announce(kind: AnnounceKind, m: Maneuver, distM: Float) {
        if (muted) return
        val p = current ?: return
        if (kind == AnnounceKind.ARRIVED) {
            speak(p.phrase("arrived")); return
        }
        val action = p.action(actionKey(m.type)).replace("{exit}", m.exit.toString())
        if (action.isBlank()) return
        var text = if (kind == AnnounceKind.FAR) {
            p.phrase("in").replace("{dist}", distText(p, distM)).replace("{action}", action)
        } else {
            p.phrase("now").replace("{action}", action)
        }
        val street = m.street
        if (!street.isNullOrBlank() && m.type != MType.ROUNDABOUT) {
            text = p.phrase("with_street").replace("{text}", text).replace("{street}", street)
        }
        speak(text.replaceFirstChar { it.uppercase() })
    }
}
