package app.offlinenav.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.offlinenav.routing.MType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Current UI language ("hu" or "en"). Reading it in a composable makes the UI update on change. */
object Lang {
    var code by mutableStateOf("hu")
    val hu: Boolean get() = code == "hu"
}

/** Inline translation: L("magyar", "english"). */
fun L(hu: String, en: String): String = if (Lang.hu) hu else en

fun fmtDist(m: Float): String {
    if (m < 1000f) {
        val v = if (m < 100f) (m / 10f).roundToInt() * 10 else (m / 50f).roundToInt() * 50
        return "$v m"
    }
    val km = m / 1000f
    val s = if (km < 100f) String.format(Locale.US, "%.1f", km) else km.roundToInt().toString()
    return (if (Lang.hu) s.replace('.', ',') else s) + " km"
}

fun fmtDur(sec: Float): String {
    val min = (sec / 60f).roundToInt().coerceAtLeast(1)
    if (min < 60) return "$min " + L("perc", "min")
    val h = min / 60
    val m = min % 60
    return if (Lang.hu) "$h ó $m p" else "$h h $m min"
}

fun fmtEta(secFromNow: Float): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (secFromNow * 1000).toLong()))

fun maneuverText(t: MType, exit: Int): String = when (t) {
    MType.LEFT -> L("Fordulj balra", "Turn left")
    MType.RIGHT -> L("Fordulj jobbra", "Turn right")
    MType.SLIGHT_LEFT -> L("Tarts balra", "Keep left")
    MType.SLIGHT_RIGHT -> L("Tarts jobbra", "Keep right")
    MType.SHARP_LEFT -> L("Élesen balra", "Sharp left")
    MType.SHARP_RIGHT -> L("Élesen jobbra", "Sharp right")
    MType.UTURN -> L("Fordulj vissza", "Make a U-turn")
    MType.ROUNDABOUT -> L("Körforgalom, $exit. kijárat", "Roundabout, exit $exit")
    MType.ARRIVE -> L("Célba érsz", "Arrive")
    MType.DEPART -> L("Indulj el", "Start")
}
