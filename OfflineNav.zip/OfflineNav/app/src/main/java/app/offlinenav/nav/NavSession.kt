package app.offlinenav.nav

import app.offlinenav.data.Geo
import app.offlinenav.routing.MType
import app.offlinenav.routing.Maneuver
import app.offlinenav.routing.Route
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class AnnounceKind { FAR, NEAR, ARRIVED }

class NavUpdate(
    val alongM: Float,
    val remainingM: Float,
    val remainingS: Float,
    val next: Maneuver,
    val distToNextM: Float,
    val offRoute: Boolean,
    val arrived: Boolean
)

/** Follows a [Route] with GPS fixes: progress, next maneuver, off-route detection, voice triggers. */
class NavSession(
    val route: Route,
    private val onAnnounce: (AnnounceKind, Maneuver, Float) -> Unit
) {
    private var progIdx = 0
    private var alongM = 0f
    private var nextIdx = 1
    private var offCount = 0
    private var arrivedSent = false
    private val far = BooleanArray(route.maneuvers.size)
    private val near = BooleanArray(route.maneuvers.size)

    fun update(lat: Int, lon: Int, speedMps: Float, accuracyM: Float): NavUpdate {
        val kx = 0.111320 * cos(Math.toRadians(lat * 1e-6))
        val ky = 0.110574
        val limit = route.cum[progIdx] + 1500f
        var bestD = Double.MAX_VALUE
        var bestI = progIdx
        var bestT = 0.0
        var i = max(progIdx - 1, 0)
        val n = route.lat.size
        while (i < n - 1 && route.cum[i] <= limit) {
            val ax = (route.lon[i] - lon) * kx
            val ay = (route.lat[i] - lat) * ky
            val bx = (route.lon[i + 1] - lon) * kx
            val by = (route.lat[i + 1] - lat) * ky
            val dx = bx - ax
            val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 <= 1e-9) 0.0 else ((-ax * dx - ay * dy) / l2).coerceIn(0.0, 1.0)
            val px = ax + t * dx
            val py = ay + t * dy
            val d = px * px + py * py
            if (d < bestD) {
                bestD = d; bestI = i; bestT = t
            }
            i++
        }
        val dist = sqrt(bestD).toFloat()
        val threshold = max(40f, accuracyM * 2f)
        if (dist > threshold) {
            offCount++
        } else {
            offCount = 0
            progIdx = bestI
            alongM = route.cum[bestI] + (bestT * (route.cum[bestI + 1] - route.cum[bestI])).toFloat()
        }
        val remaining = max(route.totalM - alongM, 0f)

        while (nextIdx < route.maneuvers.size - 1 && alongM > route.maneuvers[nextIdx].atM + 25f) nextIdx++
        val next = route.maneuvers[min(nextIdx, route.maneuvers.size - 1)]
        val distToNext = max(next.atM - alongM, 0f)

        val arrived = remaining < 25f
        if (arrived) {
            if (!arrivedSent) {
                arrivedSent = true
                onAnnounce(AnnounceKind.ARRIVED, route.maneuvers.last(), 0f)
            }
        } else if (offCount == 0 && next.type != MType.ARRIVE) {
            val farTh = (speedMps * 18f).coerceIn(250f, 1000f)
            val nearTh = (speedMps * 5f).coerceIn(40f, 150f)
            if (!far[nextIdx] && distToNext <= farTh) {
                far[nextIdx] = true
                if (distToNext > nearTh + 60f) onAnnounce(AnnounceKind.FAR, next, distToNext)
            }
            if (!near[nextIdx] && distToNext <= nearTh) {
                near[nextIdx] = true
                far[nextIdx] = true
                onAnnounce(AnnounceKind.NEAR, next, distToNext)
            }
        }
        val remainingS = route.totalS * (remaining / max(route.totalM, 1f))
        return NavUpdate(alongM, remaining, remainingS, next, distToNext, offCount >= 4, arrived)
    }

    /** Index of the first route point not yet passed (used to draw only the remaining route). */
    val progressIndex: Int get() = progIdx
}
