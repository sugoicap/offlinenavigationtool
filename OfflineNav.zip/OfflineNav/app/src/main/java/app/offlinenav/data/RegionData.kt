package app.offlinenav.data

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Normalizer
import java.util.zip.GZIPInputStream
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

object Geo {
    /** Distance in meters between two points given as degrees * 1e6 (equirectangular, fine for short spans). */
    fun distM(lat1: Int, lon1: Int, lat2: Int, lon2: Int): Float {
        val mLat = (lat2 - lat1).toDouble() * 0.110574
        val c = cos(Math.toRadians((lat1.toDouble() + lat2.toDouble()) * 0.5e-6))
        val mLon = (lon2 - lon1).toDouble() * 0.111320 * c
        return sqrt(mLat * mLat + mLon * mLon).toFloat()
    }

    /** Bearing in degrees 0..360 from point 1 to point 2. */
    fun bearing(lat1: Int, lon1: Int, lat2: Int, lon2: Int): Double {
        val dy = (lat2 - lat1).toDouble()
        val dx = (lon2 - lon1).toDouble() * cos(Math.toRadians((lat1.toDouble() + lat2.toDouble()) * 0.5e-6))
        var b = Math.toDegrees(Math.atan2(dx, dy))
        if (b < 0) b += 360.0
        return b
    }

    /** Signed difference b - a normalized to (-180, 180]. */
    fun angleDiff(a: Double, b: Double): Double {
        var d = (b - a) % 360.0
        if (d > 180.0) d -= 360.0
        if (d <= -180.0) d += 360.0
        return d
    }
}

class Place(val name: String, val lat: Int, val lon: Int, val kind: Int)

class SearchHit(val title: String, val subtitle: String, val lat: Int, val lon: Int, val isPlace: Boolean)

/** A point on a road segment. [along] is the distance in meters from the segment's first point. */
class Snap(val seg: Int, val lat: Int, val lon: Int, val along: Float, val dist: Float)

/**
 * One downloaded region: road graph + geometry + names, fully in memory.
 * File format is produced by tools/build_region.py.
 */
class RegionData(
    val id: String,
    val minLat: Int, val minLon: Int, val maxLat: Int, val maxLon: Int,
    val strings: Array<String>,
    val nodeLat: IntArray, val nodeLon: IntArray,
    val firstEdge: IntArray,
    val edgeTo: IntArray, val edgeSeg: IntArray,
    val segLen: FloatArray, val segSpeed: ByteArray, val segClass: ByteArray,
    val segFlags: ByteArray, val segName: IntArray,
    val segStart: IntArray, val geoLat: IntArray, val geoLon: IntArray,
    val placeLat: IntArray, val placeLon: IntArray, val placeKind: ByteArray, val placeName: IntArray,
    val streetLat: IntArray, val streetLon: IntArray, val streetName: IntArray
) {
    val segCount: Int = segLen.size
    val segFrom = IntArray(segCount)
    val segTo = IntArray(segCount)
    val maxSpeedKph: Int

    private val cell = 20000
    private val gw = (maxLon - minLon) / cell + 1
    private val gh = (maxLat - minLat) / cell + 1
    private val cellStart: IntArray
    private val cellItems: IntArray

    val places: Int get() = placeLat.size

    init {
        for (n in 0 until nodeLat.size) {
            for (e in firstEdge[n] until firstEdge[n + 1]) {
                val s = edgeSeg[e] shr 1
                if ((edgeSeg[e] and 1) == 0) {
                    segFrom[s] = n; segTo[s] = edgeTo[e]
                } else {
                    segTo[s] = n; segFrom[s] = edgeTo[e]
                }
            }
        }
        var ms = 30
        for (s in 0 until segCount) ms = max(ms, segSpeed[s].toInt() and 0xFF)
        maxSpeedKph = ms

        val cnt = IntArray(gw * gh + 1)
        for (s in 0 until segCount) forCells(s) { c -> cnt[c + 1]++ }
        for (i in 1 until cnt.size) cnt[i] += cnt[i - 1]
        val items = IntArray(cnt[cnt.size - 1])
        val fill = cnt.copyOf()
        for (s in 0 until segCount) forCells(s) { c -> items[fill[c]++] = s }
        cellStart = cnt
        cellItems = items
    }

    private fun cx(lon: Int) = ((lon - minLon) / cell).coerceIn(0, gw - 1)
    private fun cy(lat: Int) = ((lat - minLat) / cell).coerceIn(0, gh - 1)

    private inline fun forCells(s: Int, f: (Int) -> Unit) {
        var a = Int.MAX_VALUE
        var b = Int.MIN_VALUE
        var c = Int.MAX_VALUE
        var d = Int.MIN_VALUE
        for (i in segStart[s] until segStart[s + 1]) {
            val la = geoLat[i]
            val lo = geoLon[i]
            if (la < a) a = la
            if (la > b) b = la
            if (lo < c) c = lo
            if (lo > d) d = lo
        }
        val x0 = cx(c)
        val x1 = cx(d)
        val y0 = cy(a)
        val y1 = cy(b)
        for (y in y0..y1) for (x in x0..x1) f(y * gw + x)
    }

    fun contains(lat: Int, lon: Int) = lat in minLat..maxLat && lon in minLon..maxLon

    fun nameOf(seg: Int): String? {
        val i = segName[seg]
        return if (i < 0) null else strings[i]
    }

    fun isRoundabout(seg: Int) = (segFlags[seg].toInt() and 2) != 0
    fun isOneway(seg: Int) = (segFlags[seg].toInt() and 1) != 0

    /** Spatial query helper. Create one per thread; it keeps its own visited-stamps. */
    inner class Cursor {
        private val stamp = IntArray(segCount)
        private var gen = 0
        var buf = IntArray(4096)
            private set

        /** Fills [buf] with the segments whose grid cells touch the box; returns how many. */
        fun query(qMinLat: Int, qMinLon: Int, qMaxLat: Int, qMaxLon: Int): Int {
            gen++
            var n = 0
            val x0 = cx(qMinLon)
            val x1 = cx(qMaxLon)
            val y0 = cy(qMinLat)
            val y1 = cy(qMaxLat)
            for (y in y0..y1) for (x in x0..x1) {
                val c = y * gw + x
                for (k in cellStart[c] until cellStart[c + 1]) {
                    val s = cellItems[k]
                    if (stamp[s] != gen) {
                        stamp[s] = gen
                        if (n == buf.size) buf = buf.copyOf(n * 2)
                        buf[n++] = s
                    }
                }
            }
            return n
        }
    }

    private fun project(s: Int, lat0: Int, lon0: Int): Snap {
        val kx = 0.111320 * cos(Math.toRadians(lat0 * 1e-6))
        val ky = 0.110574
        val st = segStart[s]
        val en = segStart[s + 1]
        var bestD = Double.MAX_VALUE
        var bi = st
        var bt = 0.0
        for (i in st until en - 1) {
            val ax = (geoLon[i] - lon0) * kx
            val ay = (geoLat[i] - lat0) * ky
            val bx = (geoLon[i + 1] - lon0) * kx
            val by = (geoLat[i + 1] - lat0) * ky
            val dx = bx - ax
            val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 <= 1e-9) 0.0 else ((-ax * dx - ay * dy) / l2).coerceIn(0.0, 1.0)
            val px = ax + t * dx
            val py = ay + t * dy
            val d = px * px + py * py
            if (d < bestD) {
                bestD = d; bi = i; bt = t
            }
        }
        var along = 0.0
        for (i in st until bi) along += Geo.distM(geoLat[i], geoLon[i], geoLat[i + 1], geoLon[i + 1])
        along += bt * Geo.distM(geoLat[bi], geoLon[bi], geoLat[bi + 1], geoLon[bi + 1])
        val plat = (geoLat[bi] + bt * (geoLat[bi + 1] - geoLat[bi])).roundToInt()
        val plon = (geoLon[bi] + bt * (geoLon[bi + 1] - geoLon[bi])).roundToInt()
        return Snap(s, plat, plon, along.toFloat(), sqrt(bestD).toFloat())
    }

    /** Nearest road point within [maxM] meters, or null. */
    fun nearest(cur: Cursor, lat: Int, lon: Int, maxM: Float): Snap? {
        var r = min(150f, maxM)
        while (true) {
            val dLat = (r / 0.110574).toInt()
            val dLon = (r / (0.111320 * cos(Math.toRadians(lat * 1e-6)))).toInt()
            val n = cur.query(lat - dLat, lon - dLon, lat + dLat, lon + dLon)
            var best: Snap? = null
            for (k in 0 until n) {
                val sn = project(cur.buf[k], lat, lon)
                if (best == null || sn.dist < best.dist) best = sn
            }
            if (best != null && best.dist <= r) return best
            if (r >= maxM) return if (best != null && best.dist <= maxM) best else null
            r = min(r * 4f, maxM)
        }
    }

    // ---- search -----------------------------------------------------------------

    private val norm: Array<String> by lazy { Array(strings.size) { fold(strings[it]) } }

    fun search(query: String, centerLat: Int, centerLon: Int, limit: Int = 25): List<SearchHit> {
        val tokens = fold(query).split(' ').filter { it.isNotEmpty() }
        if (tokens.isEmpty() || query.trim().length < 2) return emptyList()
        class Cand(val score: Float, val street: Boolean, val idx: Int)

        val found = ArrayList<Cand>()
        for (i in 0 until placeName.size) {
            val n = norm[placeName[i]]
            if (tokens.all { n.contains(it) }) {
                val d = Geo.distM(centerLat, centerLon, placeLat[i], placeLon[i]) / 1000f
                val bonus = if (n.startsWith(tokens[0])) 0f else 10000f
                found.add(Cand(bonus + d * 0.2f + placeKind[i] * 2f, false, i))
            }
        }
        for (i in 0 until streetName.size) {
            val n = norm[streetName[i]]
            if (tokens.all { n.contains(it) }) {
                val d = Geo.distM(centerLat, centerLon, streetLat[i], streetLon[i]) / 1000f
                val bonus = if (n.startsWith(tokens[0])) 0f else 10000f
                found.add(Cand(bonus + d + 5f, true, i))
            }
        }
        found.sortBy { it.score }
        val out = ArrayList<SearchHit>()
        for (c in found.take(limit)) {
            if (!c.street) {
                out.add(SearchHit(strings[placeName[c.idx]], "", placeLat[c.idx], placeLon[c.idx], true))
            } else {
                out.add(
                    SearchHit(
                        strings[streetName[c.idx]], nearestPlaceName(streetLat[c.idx], streetLon[c.idx]),
                        streetLat[c.idx], streetLon[c.idx], false
                    )
                )
            }
        }
        return out
    }

    fun nearestPlaceName(lat: Int, lon: Int): String {
        var best = -1
        var bd = 15000f
        for (i in 0 until placeLat.size) {
            val d = Geo.distM(lat, lon, placeLat[i], placeLon[i])
            if (d < bd) {
                bd = d; best = i
            }
        }
        return if (best < 0) "" else strings[placeName[best]]
    }

    companion object {
        private fun fold(s: String): String =
            Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

        private class Rd(input: InputStream) {
            private val din = DataInputStream(BufferedInputStream(input, 1 shl 16))
            private val chunk = ByteArray(1 shl 16)
            fun u32(): Int {
                val b = ByteArray(4)
                din.readFully(b)
                return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int
            }

            fun bytes(n: Int): ByteArray {
                val out = ByteArray(n)
                din.readFully(out)
                return out
            }

            fun ints(n: Int): IntArray {
                val out = IntArray(n)
                var i = 0
                while (i < n) {
                    val c = min(n - i, chunk.size / 4)
                    din.readFully(chunk, 0, c * 4)
                    ByteBuffer.wrap(chunk, 0, c * 4).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer().get(out, i, c)
                    i += c
                }
                return out
            }

            fun floats(n: Int): FloatArray {
                val out = FloatArray(n)
                var i = 0
                while (i < n) {
                    val c = min(n - i, chunk.size / 4)
                    din.readFully(chunk, 0, c * 4)
                    ByteBuffer.wrap(chunk, 0, c * 4).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out, i, c)
                    i += c
                }
                return out
            }
        }

        /** Loads a .nav.gz region file. Blocking; call from a background thread. */
        fun load(file: File, id: String): RegionData {
            GZIPInputStream(file.inputStream(), 1 shl 16).use { gz ->
                val rd = Rd(gz)
                val magic = rd.bytes(4)
                require(String(magic, Charsets.US_ASCII) == "ONAV") { "Not a region file" }
                require(rd.u32() == 1) { "Unsupported region file version" }
                val n = rd.u32()
                val e = rd.u32()
                val s = rd.u32()
                val g = rd.u32()
                val p = rd.u32()
                val q = rd.u32()
                val t = rd.u32()
                val minLat = rd.u32()
                val minLon = rd.u32()
                val maxLat = rd.u32()
                val maxLon = rd.u32()
                val offs = rd.ints(t + 1)
                val blobLen = rd.u32()
                val blob = rd.bytes(blobLen)
                val strings = Array(t) { String(blob, offs[it], offs[it + 1] - offs[it], Charsets.UTF_8) }
                val nodeLat = rd.ints(n)
                val nodeLon = rd.ints(n)
                val firstEdge = rd.ints(n + 1)
                val edgeTo = rd.ints(e)
                val edgeSeg = rd.ints(e)
                val segLen = rd.floats(s)
                val segSpeed = rd.bytes(s)
                val segClass = rd.bytes(s)
                val segFlags = rd.bytes(s)
                val segName = rd.ints(s)
                val segStart = rd.ints(s + 1)
                val geoLat = rd.ints(g)
                val geoLon = rd.ints(g)
                for (i in 1 until g) {
                    geoLat[i] += geoLat[i - 1]
                    geoLon[i] += geoLon[i - 1]
                }
                val placeLat = rd.ints(p)
                val placeLon = rd.ints(p)
                val placeKind = rd.bytes(p)
                val placeName = rd.ints(p)
                val streetLat = rd.ints(q)
                val streetLon = rd.ints(q)
                val streetName = rd.ints(q)
                return RegionData(
                    id, minLat, minLon, maxLat, maxLon, strings, nodeLat, nodeLon, firstEdge, edgeTo, edgeSeg,
                    segLen, segSpeed, segClass, segFlags, segName, segStart, geoLat, geoLon,
                    placeLat, placeLon, placeKind, placeName, streetLat, streetLon, streetName
                )
            }
        }
    }
}
