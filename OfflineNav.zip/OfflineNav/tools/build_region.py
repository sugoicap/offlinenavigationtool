#!/usr/bin/env python3
"""
OfflineNav region builder.

Turns one or more OpenStreetMap extracts (.osm.pbf, or small .osm XML for tests)
into a compact, gzip-compressed region file (.nav.gz) that the app can load:
road graph + geometry + street/place names for offline search.

Usage:
  build_region.py --id hungary --name-hu Magyarország --name-en Hungary \
      --out out/ --index out/index.json  hungary.osm.pbf [austria.osm.pbf ...]

File format (little endian, whole file gzip'd) -- keep in sync with RegionData.kt:
  magic 'ONAV', u32 version(1), u32 N nodes, E edges, S segments, G geometry points,
  P places, Q streets, T strings, i32 minLat minLon maxLat maxLon  (degrees * 1e6)
  strings : u32[T+1] offsets, u32 blobLen, utf8 blob
  nodeLat i32[N], nodeLon i32[N], firstEdge u32[N+1]
  edgeTo i32[E], edgeSeg i32[E]   (seg<<1 | reversed)
  segLen f32[S], segSpeed u8[S] (kph), segClass u8[S], segFlags u8[S] (1=oneway a->b, 2=roundabout),
  segName i32[S] (-1 none), segStart u32[S+1]
  geoLatDelta i32[G], geoLonDelta i32[G]   (delta-coded over the whole point stream)
  places: lat i32[P], lon i32[P], kind u8[P], name i32[P]
  streets: lat i32[Q], lon i32[Q], name i32[Q]
"""
import argparse
import datetime
import gzip
import json
import math
import os
import re
import struct
import sys
from array import array

import numpy as np

CLASSES = {
    'motorway': 0, 'motorway_link': 0, 'trunk': 1, 'trunk_link': 1,
    'primary': 2, 'primary_link': 2, 'secondary': 3, 'secondary_link': 3,
    'tertiary': 4, 'tertiary_link': 4, 'unclassified': 5, 'residential': 6,
    'living_street': 7, 'service': 8, 'road': 5,
}
DEFAULT_KPH = {0: 110, 1: 90, 2: 80, 3: 70, 4: 60, 5: 50, 6: 30, 7: 10, 8: 20}
PLACE_KINDS = {'city': 0, 'town': 1, 'village': 2, 'suburb': 3, 'hamlet': 4}
STREET_CELL = 20000  # 0.02 deg: one search entry per street name per cell


def parse_speed(s):
    if not s:
        return None
    s = s.strip().lower()
    m = re.match(r'^(\d+(?:\.\d+)?)\s*(mph)?', s)
    if not m:
        return None
    v = float(m.group(1))
    if m.group(2):
        v *= 1.609
    return v if 5 <= v <= 140 else None


def classify(tags):
    """Return (cls, kph, oneway, reverse, flags, name) or None if not drivable."""
    hw = tags.get('highway')
    if hw not in CLASSES:
        return None
    acc = tags.get('motor_vehicle') or tags.get('vehicle') or tags.get('access')
    if acc in ('no', 'private'):
        return None
    if tags.get('area') == 'yes':
        return None
    if hw == 'service' and tags.get('service') in (
            'parking_aisle', 'driveway', 'emergency_access', 'drive-through'):
        return None
    cls = CLASSES[hw]
    mx = parse_speed(tags.get('maxspeed'))
    kph = (mx if mx else DEFAULT_KPH[cls]) * 0.85
    if hw.endswith('_link') and not mx:
        kph *= 0.7
    kph = int(max(5, min(130, round(kph))))
    junction = tags.get('junction')
    ow = tags.get('oneway')
    reverse = False
    if ow in ('yes', 'true', '1'):
        oneway = True
    elif ow in ('-1', 'reverse'):
        oneway, reverse = True, True
    elif ow in ('no', 'false', '0'):
        oneway = False
    else:
        oneway = junction in ('roundabout', 'circular') or hw in ('motorway', 'motorway_link')
    flags = 0
    if junction in ('roundabout', 'circular'):
        flags |= 2
    name = tags.get('name') or tags.get('ref')
    if name and ';' in name:
        name = name.split(';')[0].strip()
    return cls, kph, oneway, reverse, flags, name


def dist_m(lat1, lon1, lat2, lon2):
    """Same equirectangular formula as Geo.distM in the app (inputs: degrees*1e6)."""
    mlat = (lat2 - lat1) * 0.110574
    c = math.cos(math.radians((lat1 + lat2) * 0.5e-6))
    mlon = (lon2 - lon1) * 0.111320 * c
    return math.sqrt(mlat * mlat + mlon * mlon)


class Builder:
    def __init__(self):
        self.cnt = {}
        self.seen_count = set()
        self.seen_add = set()
        self.node_index = {}
        self.nlat = array('i')
        self.nlon = array('i')
        self.seg_from = array('i')
        self.seg_to = array('i')
        self.seg_len = array('f')
        self.seg_speed = array('B')
        self.seg_class = array('B')
        self.seg_flags = array('B')
        self.seg_name = array('i')
        self.seg_start = array('I', [0])
        self.glat = array('i')
        self.glon = array('i')
        self.strings = []
        self.string_idx = {}
        self.places = []  # (lat, lon, kind, name_idx)
        self.streets = []  # (lat, lon, name_idx)
        self.street_seen = set()

    # ---- pass 1: find junctions -------------------------------------------------
    def count_way(self, way_id, refs):
        if way_id is not None:
            if way_id in self.seen_count:
                return
            self.seen_count.add(way_id)
        if len(refs) < 2:
            return
        c = self.cnt
        for r in refs:
            c[r] = c.get(r, 0) + 1
        c[refs[0]] += 1
        c[refs[-1]] += 1

    # ---- pass 2: build segments -------------------------------------------------
    def _string(self, s):
        i = self.string_idx.get(s)
        if i is None:
            i = len(self.strings)
            self.strings.append(s)
            self.string_idx[s] = i
        return i

    def _node(self, ref, lat, lon):
        i = self.node_index.get(ref)
        if i is None:
            i = len(self.nlat)
            self.node_index[ref] = i
            self.nlat.append(lat)
            self.nlon.append(lon)
        return i

    def add_place(self, name, kind, lat, lon):
        k = PLACE_KINDS.get(kind)
        if k is None or not name:
            return
        self.places.append((lat, lon, k, self._string(name)))

    def add_way(self, way_id, info, pts):
        """pts: list of (ref, lat_e6, lon_e6)."""
        if way_id is not None:
            if way_id in self.seen_add:
                return
            self.seen_add.add(way_id)
        if len(pts) < 2:
            return
        cls, kph, oneway, reverse, flags, name = info
        cnt = self.cnt
        start = 0
        last = len(pts) - 1
        for i in range(1, len(pts)):
            if i == last or cnt.get(pts[i][0], 0) >= 2:
                self._add_seg(cls, kph, oneway, reverse, flags, name, pts[start:i + 1])
                start = i

    def _add_seg(self, cls, kph, oneway, reverse, flags, name, seg):
        if len(seg) < 2:
            return
        if reverse:
            seg = seg[::-1]
        length = 0.0
        for i in range(len(seg) - 1):
            length += dist_m(seg[i][1], seg[i][2], seg[i + 1][1], seg[i + 1][2])
        if length < 0.5:
            return
        a = self._node(seg[0][0], seg[0][1], seg[0][2])
        b = self._node(seg[-1][0], seg[-1][1], seg[-1][2])
        self.seg_from.append(a)
        self.seg_to.append(b)
        self.seg_len.append(length)
        self.seg_speed.append(kph)
        self.seg_class.append(cls)
        self.seg_flags.append((1 if oneway else 0) | flags)
        nidx = self._string(name) if name else -1
        self.seg_name.append(nidx)
        for _, la, lo in seg:
            self.glat.append(la)
            self.glon.append(lo)
        self.seg_start.append(len(self.glat))
        if nidx >= 0 and cls >= 2:  # search entries for named streets (not motorways/trunks)
            mid = seg[len(seg) // 2]
            key = (nidx, mid[1] // STREET_CELL, mid[2] // STREET_CELL)
            if key not in self.street_seen:
                self.street_seen.add(key)
                self.streets.append((mid[1], mid[2], nidx))

    # ---- output -----------------------------------------------------------------
    def write(self, path):
        N = len(self.nlat)
        S = len(self.seg_len)
        G = len(self.glat)
        if S == 0:
            raise SystemExit('No drivable roads found in the input.')
        frm = np.frombuffer(self.seg_from, dtype=np.int32)
        to = np.frombuffer(self.seg_to, dtype=np.int32)
        flags = np.frombuffer(self.seg_flags, dtype=np.uint8)
        seg_ids = np.arange(S, dtype=np.int32)
        two_way = (flags & 1) == 0
        e_from = np.concatenate([frm, to[two_way]]).astype(np.int32)
        e_to = np.concatenate([to, frm[two_way]]).astype(np.int32)
        e_seg = np.concatenate([seg_ids << 1, (seg_ids[two_way] << 1) | 1]).astype(np.int32)
        order = np.argsort(e_from, kind='stable')
        e_from, e_to, e_seg = e_from[order], e_to[order], e_seg[order]
        E = len(e_from)
        counts = np.bincount(e_from, minlength=N)
        first = np.concatenate([[0], np.cumsum(counts)]).astype('<u4')

        glat = np.frombuffer(self.glat, dtype=np.int32)
        glon = np.frombuffer(self.glon, dtype=np.int32)
        min_lat, max_lat = int(glat.min()), int(glat.max())
        min_lon, max_lon = int(glon.min()), int(glon.max())

        blobs = [s.encode('utf-8') for s in self.strings]
        offs = np.zeros(len(blobs) + 1, dtype='<u4')
        if blobs:
            offs[1:] = np.cumsum([len(b) for b in blobs])
        blob = b''.join(blobs)

        P, Q = len(self.places), len(self.streets)
        pl = np.array(self.places, dtype=np.int64).reshape(-1, 4) if P else np.zeros((0, 4), np.int64)
        st = np.array(self.streets, dtype=np.int64).reshape(-1, 3) if Q else np.zeros((0, 3), np.int64)

        def i4(a):
            return np.asarray(a).astype('<i4').tobytes()

        with gzip.open(path, 'wb', compresslevel=9) as f:
            f.write(b'ONAV')
            f.write(struct.pack('<IIIIIIII', 1, N, E, S, G, P, Q, len(self.strings)))
            f.write(struct.pack('<iiii', min_lat, min_lon, max_lat, max_lon))
            f.write(offs.tobytes())
            f.write(struct.pack('<I', len(blob)))
            f.write(blob)
            f.write(i4(self.nlat))
            f.write(i4(self.nlon))
            f.write(first.tobytes())
            f.write(i4(e_to))
            f.write(i4(e_seg))
            f.write(np.frombuffer(self.seg_len, dtype=np.float32).astype('<f4').tobytes())
            f.write(np.frombuffer(self.seg_speed, dtype=np.uint8).tobytes())
            f.write(np.frombuffer(self.seg_class, dtype=np.uint8).tobytes())
            f.write(flags.tobytes())
            f.write(i4(self.seg_name))
            f.write(np.frombuffer(self.seg_start, dtype=np.uint32).astype('<u4').tobytes())
            f.write(i4(np.diff(glat.astype(np.int64), prepend=0)))
            f.write(i4(np.diff(glon.astype(np.int64), prepend=0)))
            f.write(i4(pl[:, 0]))
            f.write(i4(pl[:, 1]))
            f.write(pl[:, 2].astype(np.uint8).tobytes())
            f.write(i4(pl[:, 3]))
            f.write(i4(st[:, 0]))
            f.write(i4(st[:, 1]))
            f.write(i4(st[:, 2]))
        return dict(nodes=N, edges=E, segments=S, points=G, places=P, streets=Q,
                    bbox=[min_lat, min_lon, max_lat, max_lon])


# ---- readers ---------------------------------------------------------------------
def run_xml(path, b):
    import xml.etree.ElementTree as ET
    nodes = {}
    ways = []
    for _, el in ET.iterparse(path, events=('end',)):
        if el.tag == 'node':
            nid = int(el.get('id'))
            lat, lon = round(float(el.get('lat')) * 1e6), round(float(el.get('lon')) * 1e6)
            nodes[nid] = (lat, lon)
            tags = {t.get('k'): t.get('v') for t in el.findall('tag')}
            if 'place' in tags:
                b.add_place(tags.get('name'), tags['place'], lat, lon)
            el.clear()
        elif el.tag == 'way':
            tags = {t.get('k'): t.get('v') for t in el.findall('tag')}
            refs = [int(n.get('ref')) for n in el.findall('nd')]
            ways.append((int(el.get('id')), tags, refs))
            el.clear()
    usable = [(i, classify(t), r) for i, t, r in ways]
    usable = [(i, inf, r) for i, inf, r in usable if inf]
    for i, inf, r in usable:
        b.count_way(i, r)
    for i, inf, r in usable:
        b.add_way(i, inf, [(x, nodes[x][0], nodes[x][1]) for x in r if x in nodes])


def run_pbf(paths, b):
    import osmium

    class Pass1(osmium.SimpleHandler):
        def way(self, w):
            if 'highway' in w.tags and classify(w.tags):
                b.count_way(w.id, [n.ref for n in w.nodes])

    class Pass2(osmium.SimpleHandler):
        def way(self, w):
            if 'highway' not in w.tags:
                return
            info = classify(w.tags)
            if not info:
                return
            try:
                pts = [(n.ref, int(round(n.lat * 1e6)), int(round(n.lon * 1e6))) for n in w.nodes]
            except osmium.InvalidLocationError:
                return
            b.add_way(w.id, info, pts)

        def node(self, n):
            place = n.tags.get('place')
            if place in PLACE_KINDS:
                name = n.tags.get('name')
                if name:
                    b.add_place(name, place, int(round(n.location.lat * 1e6)),
                                int(round(n.location.lon * 1e6)))

    for p in paths:
        print('pass 1:', p, flush=True)
        Pass1().apply_file(p)
    for p in paths:
        print('pass 2:', p, flush=True)
        Pass2().apply_file(p, locations=True)


def update_index(index_path, entry):
    data = {'regions': []}
    if os.path.exists(index_path):
        try:
            with open(index_path, encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            pass
    data['regions'] = [r for r in data.get('regions', []) if r.get('id') != entry['id']]
    data['regions'].append(entry)
    data['regions'].sort(key=lambda r: r.get('name_en', r['id']))
    with open(index_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('inputs', nargs='+')
    ap.add_argument('--id', required=True)
    ap.add_argument('--name-hu')
    ap.add_argument('--name-en')
    ap.add_argument('--out', default='.')
    ap.add_argument('--index')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    b = Builder()
    if all(p.endswith('.osm') or p.endswith('.xml') for p in a.inputs):
        for p in a.inputs:
            run_xml(p, b)
    else:
        run_pbf(a.inputs, b)
    fname = a.id + '.nav.gz'
    out = os.path.join(a.out, fname)
    info = b.write(out)
    size = os.path.getsize(out)
    print('built', fname, info, '%.1f MB' % (size / 1e6))
    if a.index:
        update_index(a.index, dict(
            id=a.id, file=fname, bytes=size,
            name_hu=a.name_hu or a.id.title(), name_en=a.name_en or a.id.title(),
            version=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d'),
            bbox=info['bbox']))


if __name__ == '__main__':
    sys.exit(main())
