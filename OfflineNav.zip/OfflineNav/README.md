# OfflineNav

Egyszerű, minimalista offline autós navigáció Androidra. / Simple, minimalist offline car navigation for Android.

- Régiónként letölthető térképek (nem a teljes világ) / downloadable per-region maps
- Útvonaltervezés, kanyarutasítások, újratervezés, körforgalom — internet nélkül
- Hangos navigáció: magyar és angol alapból, új hang egyszerűen hozzáadható
- Világos / sötét (OLED fekete) téma, magyar / angol felület

## 1. APK építése (telefonról)
1. Töltsd fel a repóba a fájlokat (a zip tartalmát), a `main` ágra.
2. GitHub → **Actions** → **Build APK** (magától elindul push után).
3. Ha kész: nyisd meg a futást → **Artifacts** → `OfflineNav-apk` → telepítsd az `.apk`-t.

A `.github` mappa rejtett: ha a feltöltésnél nem látszik, a fájlokat a GitHub webes szerkesztőjével is létrehozhatod
(`.github/workflows/build.yml`).

## 2. Térképek publikálása
A letöltő képernyő a repó **Releases → maps** kiadásából tölt. Ezt a workflow hozza létre:
1. Actions → **Build map region** → *Run workflow*.
2. Alapértelmezetten Magyarország. Más ország: add meg az azonosítót, neveket és a
   [Geofabrik](https://download.geofabrik.de) `.osm.pbf` linkjét (pl. Ausztria, Szlovákia…).
3. Ha lefutott, az app **⬇ Offline térképek** képernyőjén megjelenik és letölthető.

Ha nem `sugoicap/offlinenav` a repód neve, írd át a `MAPS_BASE` sort az `app/build.gradle.kts` fájlban.
Nagy országnál a workflow több percig fut; a GitHub ingyenes gépe elbírja Magyarországot, de nagyon nagy országokhoz
(pl. Németország) kevés lehet a memória — oszd régiókra.

## 3. Új hang hozzáadása
A hang egy kis JSON-fájl. Másold le a `app/src/main/assets/voices/hu-default.json` fájlt, például `de-default.json` néven,
írd át az `id`, `name`, `locale` (pl. `de-DE`) mezőket és a mondatokat. Nincs több teendő: a Beállításokban automatikusan
megjelenik. A hangot a telefon szövegfelolvasója (TTS) mondja, ezért a nyelv hangadatának telepítve kell lennie.

Szerkezet: `phrases` (keretmondatok), `actions` (kanyartípusok), `units` (méter/kilométer). A `{dist}`, `{action}`,
`{street}`, `{exit}` helyőrzők maradnak.

## Hogyan működik
`tools/build_region.py` az OSM-adatból tömör útgráfot készít (`.nav.gz`). Az app ezt tölti be memóriába,
A*-gal tervez, és saját rajzolóval jeleníti meg a térképet. Teszt: `python3 tests/test_builder.py`.

Térképadatok: © OpenStreetMap közreműködők (ODbL).
